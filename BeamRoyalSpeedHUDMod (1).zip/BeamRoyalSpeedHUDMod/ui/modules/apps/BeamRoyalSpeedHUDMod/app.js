(function () {
  "use strict";

  angular.module("beamng.apps").directive("beamRoyalSpeedHudMod", [
    "$document",
    "$timeout",
    "$log",
    function ($document, $timeout, $log) {
      return {
        replace: true,
        restrict: "EA",
        template: `
<div class="bngApp brsh-root" style="width:100%; height:100%;">
  <style>
    @font-face {
      font-family: "BRMain";
      src: url("/ui/modules/apps/BeamRoyalSpeedHUDMod/fonts/mainfont.ttf") format("truetype");
      font-weight: 100 900;
      font-style: normal;
    }

    .brsh-root {
      font-family: BRMain, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      position: relative;
      width: 100%;
      height: 100%;
      background: transparent !important;
      user-select: none;
      --brsh-animDur: 240ms;
      --brsh-flashStrength: 1;
    }

    /* =========================
       SETTINGS BUTTON (fallback)
       ========================= */
    .brsh-openBtn {
      position: fixed;
      z-index: 1000002;
      right: 12px;
      bottom: 12px;
      width: 44px;
      height: 44px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: auto;
      cursor: pointer;
      user-select: none;

      background: rgba(0,0,0,0.22);
      border: 1px solid rgba(255,255,255,0.14);
      color: rgba(255,255,255,0.92);
      box-shadow: 0 22px 70px rgba(0,0,0,0.55);
      backdrop-filter: blur(6px);
      --brshHeaderH: 120px;
      --brshPinnedH: 0px;

      opacity: 0.55;
      transition: opacity 140ms ease, transform 140ms ease, filter 140ms ease;
      filter: drop-shadow(0 10px 22px rgba(0,0,0,0.55));
      font-size: 20px;
      line-height: 1;
    }
    .brsh-openBtn:hover { opacity: 1; transform: scale(1.02); }
    .brsh-openBtn:active { transform: scale(0.98); }

    /* =========================
       HUD OVERLAY (DRAGGABLE)
       ========================= */
    .brsh-hudPos {
      position: fixed;
      z-index: 999992;
      left: 50px;
      top: 50px;
      width: 520px;
      height: 220px;
      pointer-events: none;
      overflow: visible;
      transform-origin: center;
      transition: transform 60ms linear;
    }
    .brsh-hudPos.edit {
      pointer-events: auto;
      outline: 1px dashed rgba(255,255,255,0.30);
      outline-offset: 10px;
      cursor: move;
    }

    /* inner wrapper so scale animations don't override outer translate/rotate */
    .brsh-hudInner {
      position: absolute;
      inset: 0;
      overflow: visible;
      transform-origin: center;
      pointer-events: none;
    }

    .brsh-speedWrap {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 14px;
      white-space: nowrap;
      overflow: visible;
      z-index: 4;
    }

    .brsh-speedNum {
      line-height: 1;
      letter-spacing: 0.02em;
      transform-origin: center;
      will-change: transform, filter;
      display: inline-flex;
      align-items: baseline;
    }
    .brsh-speedNum .brsh-numTail {
      display: inline-block;
      transform-origin: center;
      will-change: filter, opacity, transform;
      transition: filter 80ms linear, opacity 80ms linear;
    }

    .brsh-speedUnit {
      letter-spacing: 0.14em;
      text-transform: uppercase;
      transform-origin: left center;
      will-change: transform, filter;
    }

    /* speed change animation */
    .brsh-anim-bump { animation: brshBump var(--brsh-animDur) cubic-bezier(.2,.9,.2,1) 1; }
    .brsh-anim-slide { animation: brshSlide var(--brsh-animDur) cubic-bezier(.2,.9,.2,1) 1; }
    @keyframes brshBump {
      0%   { transform: translateY(12px) scale(0.96); opacity: 0.70; }
      55%  { transform: translateY(-2px) scale(1.06); opacity: 1; }
      100% { transform: translateY(0px) scale(1); opacity: 1; }
    }
    @keyframes brshSlide {
      0%   { transform: translateY(16px); opacity: 0.55; }
      100% { transform: translateY(0px); opacity: 1; }
    }

    /* impact punch (applied to inner wrapper now) */
    .brsh-impact {
      animation: brshImpact 320ms cubic-bezier(.2,.9,.2,1) 1;
    }
    @keyframes brshImpact {
      0% { transform: scale(1); filter: brightness(1); }
      40% { transform: scale(1.07); filter: brightness(1.35); }
      100% { transform: scale(1); filter: brightness(1); }
    }

    /* impact flash (red) */
    .brsh-impactFlash .brsh-speedNum,
    .brsh-impactFlash .brsh-speedUnit {
      animation: brshRedFlash 360ms ease-out 1;
    }
    @keyframes brshRedFlash {
      0%   { filter: drop-shadow(0 0 0 rgba(255,60,60,0)); }
      35%  { filter: drop-shadow(0 0 calc(28px * var(--brsh-flashStrength)) rgba(255,60,60,0.95)); }
      100% { filter: drop-shadow(0 0 0 rgba(255,60,60,0)); }
    }

    /* heat container */
    .brsh-heat { filter: saturate(1.2) brightness(1.06); }

    /* optional streaks (high speed) */
    .brsh-streaks { position:absolute; inset:0; pointer-events:none; z-index: 0; }
    .brsh-streaks:before {
      content:'';
      position: absolute;
      left: -38px; right: -38px;
      top: 50%;
      height: 56px;
      transform: translateY(-50%);
      background:
        linear-gradient(90deg,
          rgba(0,0,0,0) 0%,
          rgba(70,200,255,0.10) 20%,
          rgba(255,255,255,0.10) 50%,
          rgba(70,200,255,0.10) 80%,
          rgba(0,0,0,0) 100%);
      filter: blur(2px);
      opacity: 0;
      border-radius: 999px;
      transition: opacity 160ms ease;
    }
    .brsh-streaks.on:before { opacity: 1; }

    /* NEW: Heat aura (strong red) */
    .brsh-heatAura {
      position:absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%,-50%);
      pointer-events:none;
      z-index: 1;
      opacity: 0;
      filter: blur(18px);
      transition: opacity 140ms ease, transform 140ms ease, filter 140ms ease;
      mix-blend-mode: screen;
    }
    .brsh-heatAura:before {
      content:'';
      position:absolute;
      inset: 0;
      border-radius: 999px;
      background: radial-gradient(closest-side at 50% 60%,
        rgba(255,45,45,0.92),
        rgba(255,140,0,0.55) 34%,
        rgba(255,0,90,0.26) 60%,
        rgba(0,0,0,0) 76%);
      animation: brshHeatPulse 560ms ease-in-out infinite;
    }
    .brsh-heatAura.crit:before {
      animation-duration: 360ms;
      background: radial-gradient(closest-side at 50% 60%,
        rgba(255,30,30,0.98),
        rgba(255,90,0,0.62) 32%,
        rgba(255,0,120,0.30) 58%,
        rgba(0,0,0,0) 74%);
    }
    @keyframes brshHeatPulse {
      0%   { transform: scale(0.985); opacity: 0.55; }
      50%  { transform: scale(1.045); opacity: 1; }
      100% { transform: scale(0.985); opacity: 0.55; }
    }

    /* edit corner handle */
    .brsh-hudHandle {
      position: absolute;
      right: -6px;
      bottom: -6px;
      width: 22px;
      height: 22px;
      cursor: move;
      opacity: 0.95;
      pointer-events: auto;
    }
    .brsh-hudHandle:before, .brsh-hudHandle:after {
      content:'';
      position: absolute;
      right: 2px;
      bottom: 2px;
      width: 18px;
      height: 2px;
      background: rgba(255,255,255,0.42);
      transform-origin: right bottom;
      transform: rotate(-45deg);
    }
    .brsh-hudHandle:before { transform: rotate(-45deg) translateY(-5px); }
    .brsh-hudHandle:after  { transform: rotate(-45deg) translateY(2px); }

    /* =========================
       WARNING / NOTICE TEXT
       ========================= */
    .brsh-notice {
      position: fixed;
      z-index: 999991;
      left: 50px;
      top: 50px;
      pointer-events: none;
      padding: 8px 12px;
      border-radius: 16px;
      background: rgba(0,0,0,0.18);
      border: 1px solid rgba(255,255,255,0.10);
      backdrop-filter: blur(6px);
      --brshHeaderH: 120px;
      --brshPinnedH: 0px;
      overflow: visible;
      will-change: transform, opacity, filter;
      align-items: center;
      gap: 6px;
    }
    .brsh-notice.edit {
      pointer-events: auto;
      cursor: move;
      outline: 1px dashed rgba(255,255,255,0.30);
      outline-offset: 10px;
    }
    .brsh-notice .txt {
      font-weight: 950;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      white-space: nowrap;
      opacity: 0.94;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }

    .brsh-failLabel {
      font-weight: 950;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      line-height: 1;
      opacity: 0.98;
      transform-origin: center;
      will-change: transform, filter, opacity;
    }
    .brsh-failLabel.pop {
      animation: brshFailPop 720ms cubic-bezier(.2,.9,.2,1) 1;
    }
    @keyframes brshFailPop {
      0%   { transform: translateY(8px) scale(0.86); filter: brightness(0.9); opacity: 0.65; }
      45%  { transform: translateY(0px) scale(1.10); filter: brightness(1.2); opacity: 1; }
      100% { transform: translateY(0px) scale(1); filter: brightness(1); opacity: 1; }
    }

    /* "dangerously slow" countdown */
    .brsh-dangerWrap {
      position: absolute;
      left: 50%;
      top: -16px;
      transform: translateX(-50%);
      display:flex;
      flex-direction: column;
      align-items: center;
      pointer-events: none;
      gap: 6px;
      z-index: 3;
    }
    .brsh-dangerCountdown {
      font-weight: 950;
      letter-spacing: 0.08em;
      border-radius: 16px;
      padding: 10px 14px;
      background: rgba(255,60,60,0.18);
      border: 1px solid rgba(255,80,80,0.30);
      box-shadow: 0 22px 80px rgba(0,0,0,0.55);
      backdrop-filter: blur(10px);
      animation: brshPulse 520ms ease-in-out infinite;
    }
    .brsh-dangerCountdown.crit {
      background: rgba(255,30,30,0.24);
      border-color: rgba(255,90,90,0.44);
      animation: brshPulseCrit 360ms ease-in-out infinite;
    }
    @keyframes brshPulse {
      0% { transform: scale(0.985); filter: brightness(1); }
      50% { transform: scale(1.03); filter: brightness(1.22); }
      100% { transform: scale(0.985); filter: brightness(1); }
    }
    @keyframes brshPulseCrit {
      0% { transform: scale(0.975); filter: brightness(1.05) saturate(1.2); }
      50% { transform: scale(1.055); filter: brightness(1.35) saturate(1.35); }
      100% { transform: scale(0.975); filter: brightness(1.05) saturate(1.2); }
    }

    .brsh-dangerSub {
      font-weight: 950;
      letter-spacing: 0.10em;
      text-transform: uppercase;
      color: rgba(255,255,255,0.92);
      text-shadow: 0 10px 22px rgba(0,0,0,0.55);
      opacity: 0.92;
    }

    .brsh-boostBanner {
      position: absolute;
      left: 50%;
      top: -54px;
      transform: translate(-50%, 14px) scale(0.96);
      pointer-events: none;
      z-index: 5;
      opacity: 0;
      white-space: nowrap;
      font-weight: 950;
      letter-spacing: 0.10em;
      text-transform: uppercase;
      padding: 10px 16px;
      border-radius: 16px;
      background: rgba(0,0,0,0.28);
      border: 1px solid rgba(255,255,255,0.16);
      box-shadow: 0 24px 70px rgba(0,0,0,0.55);
      backdrop-filter: blur(10px);
      transition: opacity 180ms ease, transform 180ms cubic-bezier(.2,.9,.2,1), filter 180ms ease;
      filter: blur(4px);
    }
    .brsh-boostBanner.show {
      opacity: 1;
      transform: translate(-50%, 0px) scale(1);
      filter: blur(0px);
    }

    /* FAIL overlay */
    .brsh-failOverlay {
      position: fixed;
      z-index: 999999;
      left: 0; top: 0; right: 0; bottom: 0;
      pointer-events: none;
      display:flex;
      align-items:center;
      justify-content:center;
      background: radial-gradient(120% 120% at 50% 40%, rgba(255,60,60,0.14), rgba(0,0,0,0.0) 62%);
      animation: brshFailFlash 1200ms cubic-bezier(.2,.9,.2,1) 1;
    }
    @keyframes brshFailFlash {
      0% { opacity: 0; filter: blur(6px); }
      15% { opacity: 1; filter: blur(0px); }
      70% { opacity: 1; }
      100% { opacity: 0; }
    }
    .brsh-failText {
      font-weight: 950;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: rgba(255,255,255,0.95);
      text-shadow: 0 26px 90px rgba(0,0,0,0.70);
      background: rgba(0,0,0,0.30);
      border: 1px solid rgba(255,255,255,0.16);
      border-radius: 22px;
      padding: 16px 22px;
      backdrop-filter: blur(12px);
    }
    .brsh-failText .small {
      display:block;
      margin-top: 8px;
      font-size: 12px;
      letter-spacing: 0.10em;
      opacity: 0.75;
      text-transform: none;
    }

    /* subtle fire overlay (UI-only) */
    .brsh-fireFX {
      position:absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%,-50%);
      pointer-events:none;
      width: 220px;
      height: 220px;
      opacity: 0;
      filter: blur(0px);
      transition: opacity 140ms ease, transform 140ms ease;
      mix-blend-mode: screen;
      z-index: 2;
    }
    .brsh-fireFX.on {
      opacity: 1;
      transform: translate(-50%,-50%) scale(1.02);
      filter: blur(0.4px);
    }
    .brsh-fireFX:before, .brsh-fireFX:after {
      content:'';
      position:absolute;
      inset: 0;
      border-radius: 999px;
      background: radial-gradient(closest-side at 48% 64%,
        rgba(255,210,80,0.22),
        rgba(255,120,0,0.18) 35%,
        rgba(255,60,60,0.10) 55%,
        rgba(0,0,0,0) 72%);
      animation: brshFire 580ms ease-in-out infinite;
    }
    .brsh-fireFX:after {
      opacity: 0.75;
      filter: blur(2px);
      animation-duration: 720ms;
    }
    @keyframes brshFire {
      0% { transform: translateY(2px) scale(0.98); opacity: 0.55; }
      50% { transform: translateY(-4px) scale(1.03); opacity: 0.95; }
      100% { transform: translateY(2px) scale(0.98); opacity: 0.55; }
    }

    .brsh-icon {
      width: 20px;
      height: 20px;
      opacity: 0.92;
      flex: 0 0 auto;
      filter: drop-shadow(0 8px 18px rgba(0,0,0,0.55));
    }

    /* =========================
       SETTINGS PANEL
       ========================= */
    .brsh-settings {
      position: fixed;
      z-index: 999999;
      background: rgba(12,14,18,0.92);
      border: 1px solid rgba(255,255,255,0.14);
      border-radius: 18px;
      box-shadow: 0 26px 80px rgba(0,0,0,0.62);
      overflow: hidden;
      pointer-events: auto;
      backdrop-filter: blur(6px);
      --brshHeaderH: 120px;
      --brshPinnedH: 0px;
    }
    .brsh-settingsHeader {
      padding: 12px 12px 10px 12px;
      border-bottom: 1px solid rgba(255,255,255,0.10);
      cursor: grab;
      user-select: none;
      background: linear-gradient(180deg, rgba(18,20,26,0.86), rgba(12,14,18,0.72));
    }
    .brsh-settingsHeader:active { cursor: grabbing; }
    .brsh-titleRow { display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .brsh-title { font-size: 13px; font-weight: 850; letter-spacing: 0.10em; text-transform: uppercase; color: rgba(255,255,255,0.92); }
    .brsh-close {
      border: 1px solid rgba(255,255,255,0.14);
      background: rgba(0,0,0,0.24);
      color: rgba(255,255,255,0.92);
      width: 34px; height: 34px; border-radius: 12px;
      cursor: pointer;
    }
    .brsh-sub { margin-top: 8px; font-size: 12px; color: rgba(255,255,255,0.70); line-height: 1.35; }
    .brsh-kbd { margin-top: 6px; font-size: 11px; letter-spacing: 0.08em; color: rgba(255,255,255,0.55); }
    .brsh-settingsBody {
      padding: 12px;
      overflow: auto;
      height: calc(100% - var(--brshHeaderH) - var(--brshPinnedH));
    }

    /* Pinned position toggles (always visible, does NOT overlap scroll content) */
    .brsh-pinnedTop {
      padding: 12px;
      border-bottom: 1px solid rgba(255,255,255,0.10);
      background: rgba(0,0,0,0.10);
    }
    .brsh-pinCard {
      border: 1px solid rgba(255,255,255,0.10);
      background: rgba(0,0,0,0.18);
      border-radius: 16px;
      padding: 12px;
    }
    .brsh-pinCard h3 { margin: 0 0 10px 0; font-size: 12px; font-weight: 900; letter-spacing: 0.12em; text-transform: uppercase; color: rgba(255,255,255,0.86); }

    .brsh-sec {
      border: 1px solid rgba(255,255,255,0.10);
      background: linear-gradient(180deg, rgba(255,255,255,0.03), rgba(0,0,0,0.18));
      border-radius: 18px;
      padding: 14px;
      margin-bottom: 14px;
      box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);
    }
    .brsh-sec h3 {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0 0 12px 0;
      font-size: 12px;
      font-weight: 900;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      color: rgba(255,255,255,0.88);
    }
    .brsh-subsec {
      margin: 14px 0 6px 0;
      padding-top: 12px;
      border-top: 1px solid rgba(255,255,255,0.10);
      font-size: 10px;
      font-weight: 900;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      color: rgba(255,255,255,0.58);
    }
    .brsh-sec > .brsh-subsec:first-of-type {
      margin-top: 2px;
      padding-top: 0;
      border-top: 0;
    }

    .brsh-row {
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 12px;
      align-items: center;
      padding: 12px 0;
      border-top: 1px solid rgba(255,255,255,0.06);
    }
    .brsh-row:first-of-type { border-top: 0; padding-top: 0; }
    .brsh-subsec + .brsh-row { padding-top: 10px; }
    .brsh-name { font-size: 12px; font-weight: 750; color: rgba(255,255,255,0.94); }
    .brsh-desc { font-size: 11px; color: rgba(255,255,255,0.62); line-height: 1.35; }

    .brsh-seg {
      display: inline-flex;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 12px;
      overflow: hidden;
      background: rgba(0,0,0,0.20);
    }
    .brsh-seg button {
      border: 0;
      background: transparent;
      color: rgba(255,255,255,0.72);
      font-size: 12px;
      padding: 8px 10px;
      cursor: pointer;
      white-space: nowrap;
    }
    .brsh-seg button + button { border-left: 1px solid rgba(255,255,255,0.10); }
    .brsh-seg button.active { background: rgba(70,200,255,0.14); color: rgba(255,255,255,0.92); }

    /* Color palette buttons (HUD text color) */
    .brsh-colorPalette {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      justify-content: flex-end;
      max-width: 280px;
    }
    .brsh-colorSwatch {
      width: 22px;
      height: 22px;
      border-radius: 8px;
      border: 1px solid rgba(255,255,255,0.18);
      background: transparent;
      cursor: pointer;
      padding: 0;
      box-shadow: 0 10px 26px rgba(0,0,0,0.40);
    }
    .brsh-colorSwatch.active {
      outline: 2px solid rgba(70,200,255,0.75);
      outline-offset: 2px;
    }

    .brsh-slider { min-width: 280px; display: grid; gap: 6px; }
    .brsh-slider input { width: 280px; }
    .brsh-val { font-size: 11px; color: rgba(255,255,255,0.62); letter-spacing: 0.06em; }

    .brsh-switch {
      width: 46px; height: 26px;
      border-radius: 999px;
      border: 1px solid rgba(255,255,255,0.14);
      background: rgba(0,0,0,0.22);
      position: relative;
      cursor: pointer;
    }
    .brsh-switch .thumb {
      width: 22px; height: 22px;
      border-radius: 999px;
      background: rgba(255,255,255,0.85);
      position: absolute;
      top: 1px; left: 1px;
      transition: left 120ms ease, background 120ms ease;
    }
    .brsh-switch.on { background: rgba(70,200,255,0.16); }
    .brsh-switch.on .thumb { left: 22px; background: rgba(255,255,255,0.95); }

    .brsh-btn {
      border: 1px solid rgba(255,255,255,0.14);
      background: rgba(0,0,0,0.24);
      color: rgba(255,255,255,0.92);
      border-radius: 12px;
      padding: 9px 10px;
      cursor: pointer;
      white-space: nowrap;
      margin-left: 8px;
    }
    .brsh-btn.danger { border-color: rgba(255,120,120,0.30); background: rgba(255,120,120,0.10); }

    .brsh-input {
      width: 280px;
      box-sizing: border-box;
      border-radius: 12px;
      border: 1px solid rgba(255,255,255,0.14);
      background: rgba(0,0,0,0.18);
      color: rgba(255,255,255,0.92);
      padding: 10px 10px;
      outline: none;
      font-size: 12px;
    }
    .brsh-input::placeholder { color: rgba(255,255,255,0.45); }

    .brsh-btn.primary { border-color: rgba(70,200,255,0.28); background: rgba(70,200,255,0.14); }

    .brsh-noteWarn {
      display: grid;
      grid-template-columns: auto 1fr;
      gap: 10px;
      align-items: start;
      margin: 12px 0 4px 0;
      padding: 12px;
      border-radius: 16px;
      border: 1px solid rgba(255,190,70,0.24);
      background: linear-gradient(180deg, rgba(255,190,70,0.11), rgba(255,120,60,0.05));
      box-shadow: inset 0 1px 0 rgba(255,255,255,0.03);
    }
    .brsh-noteWarnBadge {
      width: 24px;
      height: 24px;
      border-radius: 999px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      font-weight: 950;
      color: rgba(255,255,255,0.96);
      background: rgba(255,180,50,0.18);
      border: 1px solid rgba(255,220,120,0.22);
      box-shadow: 0 12px 24px rgba(0,0,0,0.25);
    }
    .brsh-noteWarnTitle {
      font-size: 11px;
      font-weight: 850;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: rgba(255,242,210,0.92);
      margin-bottom: 4px;
    }
    .brsh-noteWarnText {
      font-size: 11px;
      line-height: 1.45;
      color: rgba(255,235,205,0.78);
    }

    .brsh-modalBack {
      position: fixed;
      inset: 0;
      z-index: 1000005;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      background: rgba(0,0,0,0.38);
      backdrop-filter: blur(4px);
      pointer-events: auto;
    }
    .brsh-dsePopup {
      position: relative;
      width: min(560px, calc(100vw - 40px));
      border-radius: 22px;
      border: 1px solid rgba(255,255,255,0.14);
      background: linear-gradient(180deg, rgba(18,20,26,0.98), rgba(10,12,16,0.96));
      box-shadow: 0 30px 90px rgba(0,0,0,0.62);
      padding: 20px 20px 18px 20px;
      overflow: hidden;
    }
    .brsh-dsePopup:before {
      content: '';
      position: absolute;
      left: 0;
      right: 0;
      top: 0;
      height: 4px;
      background: linear-gradient(90deg, rgba(255,160,50,0.95), rgba(255,80,80,0.95));
    }
    .brsh-dseClose {
      position: absolute;
      right: 14px;
      top: 14px;
      width: 34px;
      height: 34px;
      border-radius: 12px;
      border: 1px solid rgba(255,255,255,0.14);
      background: rgba(0,0,0,0.22);
      color: rgba(255,255,255,0.92);
      cursor: pointer;
      font-size: 14px;
    }
    .brsh-dseEyebrow {
      font-size: 11px;
      font-weight: 900;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: rgba(255,196,96,0.96);
      margin-bottom: 8px;
    }
    .brsh-dseTitle {
      font-size: 24px;
      font-weight: 950;
      line-height: 1.06;
      color: rgba(255,255,255,0.96);
      margin-bottom: 10px;
      padding-right: 42px;
    }
    .brsh-dseText {
      font-size: 13px;
      line-height: 1.5;
      color: rgba(255,255,255,0.76);
    }
    .brsh-dseCheck {
      margin-top: 16px;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-size: 12px;
      color: rgba(255,255,255,0.86);
      cursor: pointer;
    }
    .brsh-dseCheck input {
      width: 16px;
      height: 16px;
      accent-color: rgba(70,200,255,1);
      cursor: pointer;
    }
    .brsh-dseActions {
      margin-top: 18px;
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
    .brsh-dseActions .brsh-btn { margin-left: 0; min-width: 100px; }

    .brsh-resize { position:absolute; right:10px; bottom:10px; width:18px; height:18px; cursor:nwse-resize; opacity:0.85; }
    .brsh-resize:before, .brsh-resize:after { content:''; position:absolute; right:0; bottom:0; width:16px; height:2px; background: rgba(255,255,255,0.35); transform-origin:right bottom; transform: rotate(-45deg); }
    .brsh-resize:before { transform: rotate(-45deg) translateY(-4px); }
    .brsh-resize:after  { transform: rotate(-45deg) translateY(2px); }
  </style>

  <!-- SETTINGS BUTTON -->
  <div class="brsh-openBtn"
       ng-if="vm.settings.showSettingsButton"
       ng-click="vm.toggleSettings()"
       title="Speed HUD Settings (Alt+Numpad4)">
    ⚙
  </div>

  <!-- INSTANT BOOST DSE POPUP -->
  <div class="brsh-modalBack" ng-if="vm.ui.dsePopupVisible">
    <div class="brsh-dsePopup">
      <button class="brsh-dseClose" ng-click="vm.closeDsePopup()" title="Close">✕</button>
      <div class="brsh-dseEyebrow">⚠️ Instant Boost setup</div>
      <div class="brsh-dseTitle">Driving &amp; Safety Electronics should be set to Empty</div>
      <div class="brsh-dseText">
        Some cars can interpret Instant Boost as an emergency event and force full braking / hazard lights.
        If that happens on this car, open <b>Vehicle Config</b> and set <b>Driving &amp; Safety Electronics</b> to <b>Empty</b>.
      </div>
      <label class="brsh-dseCheck">
        <input type="checkbox" ng-model="vm.settings.dsePopupDontShowAgain" ng-change="vm.onDsePopupPrefChanged()"/>
        <span>✔ Don't show this again</span>
      </label>
      <div class="brsh-dseActions">
        <button class="brsh-btn primary" ng-click="vm.closeDsePopup()">Okay</button>
      </div>
    </div>
  </div>

  <!-- WARNING NOTICE -->
  <div class="brsh-notice"
       ng-if="vm.settings.noticeEnabled && vm.ui.noticeVisible"
       ng-style="vm.ui.noticeStyle"
       ng-class="{edit: vm.ui.noticeEdit}"
       ng-mousedown="vm.ui.noticeEdit ? vm.ui.noticeDragStart($event) : null">

    <div class="txt" ng-style="vm.ui.noticeTextStyle">
      <img class="brsh-icon" ng-if="vm.settings.noticeShowIcon" ng-src="/ui/modules/apps/BeamRoyalSpeedHUDMod/icons/warn.svg"/>
      {{ vm.ui.noticeText }}
    </div>

    <div class="brsh-failLabel"
         ng-if="vm.ui.failLabelVisible"
         ng-class="{pop: vm.ui.failLabelPop}"
         ng-style="vm.ui.failLabelStyle">
      FAILED!
    </div>
  </div>

  <!-- SPEED HUD -->
  <div class="brsh-hudPos"
       ng-if="vm.settings.hudVisible"
       ng-style="vm.ui.hudStyle"
       ng-class="{
         edit: vm.ui.hudEdit,
         'brsh-heat': vm.ui.heatOn
       }"
       ng-mousedown="vm.ui.hudEdit ? vm.ui.hudDragStart($event) : null">

    <div class="brsh-hudInner" ng-class="{ 'brsh-impact': vm.ui.impactPunch }">

      <div class="brsh-streaks" ng-class="{on: vm.ui.streaksOn}"></div>

      <div class="brsh-heatAura" ng-class="{crit: vm.ui.heatAuraCrit}" ng-style="vm.ui.heatAuraStyle"></div>

      <div class="brsh-fireFX" ng-class="{on: vm.ui.fireOn}" ng-style="vm.ui.fireStyle"></div>

      <div class="brsh-dangerWrap" ng-if="vm.ui.dangerVisible">
        <div class="brsh-dangerCountdown" ng-class="{crit: vm.ui.dangerCritical}" ng-style="vm.ui.dangerStyle">
          {{ vm.ui.dangerText }}
        </div>
        <div class="brsh-dangerSub" ng-if="vm.ui.dangerSubText" ng-style="vm.ui.dangerSubStyle">{{ vm.ui.dangerSubText }}</div>
      </div>

      <div class="brsh-boostBanner"
           ng-if="vm.ui.boostBannerVisible"
           ng-class="{show: vm.ui.boostBannerShow}">
        {{ vm.ui.boostBannerText }}
      </div>

      <div class="brsh-speedWrap" ng-style="vm.ui.speedWrapStyle" ng-class="{ 'brsh-impactFlash': vm.ui.impactFlash }">
        <span class="brsh-speedNum"
              ng-class="vm.ui.animClass"
              ng-style="vm.ui.speedStyle">
          <span class="brsh-numMain">{{ vm.ui.speedTextMain }}</span><span class="brsh-numTail" ng-style="vm.ui.speedTailStyle">{{ vm.ui.speedTextTail }}</span>
        </span>
        <span class="brsh-speedUnit"
              ng-if="vm.settings.showUnit"
              ng-style="vm.ui.unitStyle">{{ vm.ui.unitText }}</span>
      </div>

    </div>

    <div class="brsh-hudHandle" ng-if="vm.ui.hudEdit"></div>
  </div>

  <!-- FAIL overlay -->
  <div class="brsh-failOverlay" ng-if="vm.ui.failFlash">
    <div class="brsh-failText" ng-style="vm.ui.failStyle">
      FAILED
      <span class="small">below {{ vm.settings.challengeStartSpeed }} {{ vm.settings.units }}</span>
    </div>
  </div>

  <!-- SETTINGS PANEL -->
  <div class="brsh-settings" ng-if="vm.ui.settingsOpen" ng-style="vm.ui.panelStyle">
    <div class="brsh-settingsHeader" ng-mousedown="vm.ui.dragStart($event)">
      <div class="brsh-titleRow">
        <div class="brsh-title">Speed HUD Mod</div>
        <button class="brsh-close" ng-click="vm.toggleSettings()" title="Close">✕</button>
      </div>
      <div class="brsh-sub">
        mod made by <b>@BeamRoyal</b> on YouTube<br/>
        part of the <b>BeamNG Creator Kit</b> by BeamRoyale (ko-fi.com/beamroyale)
      </div>
      <div class="brsh-kbd">Hotkeys: Alt + Numpad 4 (Settings) • Alt + Numpad 5 (Reset Challenge) • Alt + Numpad 6 (Instant Boost)</div>
    </div>

    <!-- Pinned position toggles (always visible) -->
    <div class="brsh-pinnedTop">
      <div class="brsh-pinCard">
        <h3>🧭 Position</h3>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Edit HUD Position</div>
            <div class="brsh-desc">Drag the HUD on-screen. It will auto-snap to the screen center while dragging.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.ui.hudEdit}" ng-click="vm.toggleHudEdit()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Edit Notice Position</div>
            <div class="brsh-desc">Drag the warning notice (if enabled).</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.ui.noticeEdit}" ng-click="vm.toggleNoticeEdit()"><div class="thumb"></div></div>
        </div>
      </div>
    </div>

    <div class="brsh-settingsBody">

      <!-- Position tools (scrolls with the rest) -->
      <div class="brsh-sec">
        <h3>🧭 Position Tools</h3>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Snap HUD</div>
            <div class="brsh-desc">Quick align to top / middle / bottom center.</div>
          </div>
          <div class="brsh-seg">
            <button ng-click="vm.snapHud('top')">Top</button>
            <button ng-click="vm.snapHud('center')">Middle</button>
            <button ng-click="vm.snapHud('bottom')">Bottom</button>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Reset Positions</div>
            <div class="brsh-desc">Restores default HUD + notice positions.</div>
          </div>
          <button class="brsh-btn" ng-click="vm.resetPositions()">Reset</button>
        </div>
      </div>

      <div class="brsh-sec">
        <h3>🏎️ Speed HUD</h3>

        <div class="brsh-subsec">⚙️ Basics</div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Show Speed HUD</div>
            <div class="brsh-desc">Toggle the speed overlay on/off.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.hudVisible}" ng-click="vm.toggleHudVisible()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Units</div>
            <div class="brsh-desc">km/h or mph.</div>
          </div>
          <div class="brsh-seg">
            <button ng-class="{active: vm.settings.units==='kmh'}" ng-click="vm.setUnits('kmh')">km/h</button>
            <button ng-class="{active: vm.settings.units==='mph'}" ng-click="vm.setUnits('mph')">mph</button>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Speed Source</div>
            <div class="brsh-desc">Choose wheel speed, air speed (for jumps), or Dynamic (auto). Dynamic blends seamlessly.</div>
          </div>
          <div class="brsh-seg">
            <button ng-class="{active: vm.settings.speedSource==='wheel'}" ng-click="vm.setSpeedSource('wheel')">Wheel</button>
            <button ng-class="{active: vm.settings.speedSource==='air'}" ng-click="vm.setSpeedSource('air')">Air</button>
            <button ng-class="{active: vm.settings.speedSource==='dynamic'}" ng-click="vm.setSpeedSource('dynamic')">Dynamic</button>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Source Transition</div>
            <div class="brsh-desc">Blend time when switching wheel ↔ air (recommended 0.3–0.5s).</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="100" max="900" step="10" ng-model="vm.settings.speedSourceBlendMs" ng-change="vm.setSpeedSourceBlendMs(vm.settings.speedSourceBlendMs)"/>
            <div class="brsh-val">{{ (vm.settings.speedSourceBlendMs/1000) | number:2 }} s</div>
          </div>
        </div>

        <div class="brsh-subsec">🎯 Speed Control</div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🎯 Target Speed Lock</div>
            <div class="brsh-desc">Type a speed and accelerate normally. Once you hit the target, the car will try to hold that speed until you reset the vehicle.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.speedLockEnabled}" ng-click="vm.toggleSpeedLock()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🎯 Lock Speed</div>
            <div class="brsh-desc">Enter target speed (examples: <b>100 km/h</b> or <b>62 mph</b>). If you type only a number, it uses the <b>Units</b> setting above.</div>
          </div>
          <div>
            <input class="brsh-input" type="text" placeholder="100 km/h" ng-model="vm.ui.speedLockTargetDisplay" ng-change="vm.onSpeedLockTargetInput()" ng-blur="vm.onSpeedLockTargetBlur()"/>
          </div>
        </div>

        <div class="brsh-subsec">🚀 Instant Boost</div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🚀 Instant Boost</div>
            <div class="brsh-desc">Clean speed boost using BeamNG's <b>thrusters.applyVelocity</b>, with a softer free-roll release so the car can coast instead of feeling brake-locked. Press <b>Alt + Numpad 6</b> to trigger.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.instantAccelEnabled}" ng-click="vm.toggleInstantAccel()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-noteWarn">
          <div class="brsh-noteWarnBadge">!</div>
          <div>
            <div class="brsh-noteWarnTitle">Driving &amp; Safety Electronics → Empty</div>
            <div class="brsh-noteWarnText">Some cars use safety systems that can treat Instant Boost like an emergency event and lock the brakes or flash the hazards. If that happens on a car, open <b>Vehicle Config</b> and set <b>Driving &amp; Safety Electronics</b> to <b>Empty</b> for that vehicle.</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.instantAccelEnabled">
          <div>
            <div class="brsh-name">🚀 Boost Mode</div>
            <div class="brsh-desc"><b>Set</b> = speed up to the target. <b>Add</b> = add this amount to current speed.</div>
          </div>
          <div class="brsh-seg">
            <button ng-class="{active: vm.settings.instantAccelMode==='set'}" ng-click="vm.setInstantAccelMode('set')">Set</button>
            <button ng-class="{active: vm.settings.instantAccelMode==='add'}" ng-click="vm.setInstantAccelMode('add')">Add</button>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.instantAccelEnabled">
          <div>
            <div class="brsh-name">🚀 Boost Speed</div>
            <div class="brsh-desc">Enter a speed (examples: <b>1000 mph</b>, <b>1600 km/h</b>, <b>250 m/s</b>). If you type only a number, it uses the <b>Units</b> setting above.</div>
          </div>
          <div>
            <input class="brsh-input" type="text" placeholder="1000 mph" ng-model="vm.ui.instantAccelSpeedDisplay" ng-change="vm.onInstantAccelSpeedInput()" ng-blur="vm.onInstantAccelSpeedBlur()"/>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.instantAccelEnabled">
          <div>
            <div class="brsh-name">🚀 Boost Popup Text</div>
            <div class="brsh-desc">Shows a clean <b>INSTANT BOOST ... 🚀</b> banner above the HUD for about 1 second.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.instantAccelBannerEnabled}" ng-click="vm.toggleInstantAccelBanner()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.instantAccelEnabled">
          <div>
            <div class="brsh-name">⏱️ Hold Duration</div>
            <div class="brsh-desc">How long to keep applying the target speed after pressing the hotkey. Use <b>0</b> for one-shot.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0" max="6.00" step="0.05" ng-model="vm.settings.instantAccelDuration"/>
            <div class="brsh-val">{{ vm.settings.instantAccelDuration }} s</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.instantAccelEnabled">
          <div>
            <div class="brsh-name">📈 Ramp Time</div>
            <div class="brsh-desc">Smooth ramp-up time (0 = instant).</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0" max="1.00" step="0.02" ng-model="vm.settings.instantAccelRamp"/>
            <div class="brsh-val">{{ vm.settings.instantAccelRamp }} s</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.instantAccelEnabled">
          <div>
            <div class="brsh-name">↔️ Invert Direction</div>
            <div class="brsh-desc">If the boost ever sends the car backwards on your build, enable this.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.instantAccelInvertDir}" ng-click="vm.toggleInstantAccelInvertDir()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-subsec">🎨 Text & Layout</div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🔢 Decimals</div>
            <div class="brsh-desc">Use 0 for clean shorts look.</div>
          </div>
          <div class="brsh-seg">
            <button ng-class="{active: vm.settings.decimals===0}" ng-click="vm.setDecimals(0)">0</button>
            <button ng-class="{active: vm.settings.decimals===1}" ng-click="vm.setDecimals(1)">1</button>
            <button ng-class="{active: vm.settings.decimals===2}" ng-click="vm.setDecimals(2)">2</button>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🏁 Show Unit</div>
            <div class="brsh-desc">Show km/h or mph next to the number.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.showUnit}" ng-click="vm.toggleShowUnit()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🔠 Text Size</div>
            <div class="brsh-desc">Main speed number size.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="28" max="260" step="1" ng-model="vm.settings.fontSize"/>
            <div class="brsh-val">{{ vm.settings.fontSize }} px</div>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🌗 Opacity</div>
            <div class="brsh-desc">Overall visibility.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0.20" max="1.00" step="0.02" ng-model="vm.settings.textOpacity"/>
            <div class="brsh-val">{{ vm.settings.textOpacity }}</div>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🎨 HUD Color</div>
            <div class="brsh-desc">Base color for the speed text (useful for themed overlays).</div>
          </div>
          <div class="brsh-colorPalette">
            <button class="brsh-colorSwatch"
                    ng-repeat="c in vm.hudColorPalette"
                    ng-style="{background: c}"
                    ng-class="{active: vm.settings.hudColor===c}"
                    ng-click="vm.setHudColor(c)"
                    title="{{ c }}"></button>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🎨 Custom HUD Color</div>
            <div class="brsh-desc">Hex color (example: #00ff99). Leave empty to use white.</div>
          </div>
          <div>
            <input class="brsh-input" type="text" ng-model="vm.settings.hudColor" maxlength="16" placeholder="#ffffff"/>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">📏 Unit Scale</div>
            <div class="brsh-desc">Unit size relative to number.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0.12" max="0.45" step="0.01" ng-model="vm.settings.unitScale"/>
            <div class="brsh-val">{{ vm.settings.unitScale }}</div>
          </div>
        </div>
      </div>

      <div class="brsh-sec">
        <h3>✨ Shadow & Outline</h3>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Drop Shadow</div>
            <div class="brsh-desc">Soft shadow behind the speed.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.shadowEnabled}" ng-click="vm.toggleShadow()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.shadowEnabled">
          <div>
            <div class="brsh-name">Shadow Controls</div>
            <div class="brsh-desc">Blur / opacity / offsets.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0" max="80" step="1" ng-model="vm.settings.shadowBlur"/><div class="brsh-val">Blur: {{ vm.settings.shadowBlur }} px</div>
            <input type="range" min="-40" max="40" step="1" ng-model="vm.settings.shadowX"/><div class="brsh-val">Offset X: {{ vm.settings.shadowX }} px</div>
            <input type="range" min="-40" max="40" step="1" ng-model="vm.settings.shadowY"/><div class="brsh-val">Offset Y: {{ vm.settings.shadowY }} px</div>
            <input type="range" min="0" max="1" step="0.05" ng-model="vm.settings.shadowOpacity"/><div class="brsh-val">Opacity: {{ vm.settings.shadowOpacity }}</div>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">Outline</div>
            <div class="brsh-desc">Stroke-like outline around the speed.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.outlineEnabled}" ng-click="vm.toggleOutline()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.outlineEnabled">
          <div>
            <div class="brsh-name">Outline Controls</div>
            <div class="brsh-desc">Thickness + opacity + color.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="1" max="10" step="1" ng-model="vm.settings.outlineSize"/><div class="brsh-val">Size: {{ vm.settings.outlineSize }} px</div>
            <input type="range" min="0" max="1" step="0.05" ng-model="vm.settings.outlineOpacity"/><div class="brsh-val">Opacity: {{ vm.settings.outlineOpacity }}</div>
            <div class="brsh-seg">
              <button ng-class="{active: vm.settings.outlineColor==='dark'}" ng-click="vm.setOutlineColor('dark')">Dark</button>
              <button ng-class="{active: vm.settings.outlineColor==='light'}" ng-click="vm.setOutlineColor('light')">Light</button>
            </div>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">NOTE</div>
            <div class="brsh-desc">Notice text automatically inherits Shadow + Outline settings.</div>
          </div>
          <div></div>
        </div>
      </div>

      <div class="brsh-sec">
        <h3>⚡ Reactive Motion</h3>

        <div class="brsh-subsec">🌪️ Motion & Impact</div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🌪️ G-Force Shake</div>
            <div class="brsh-desc">Stable shake (no constant micro-wiggle).</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.gShakeEnabled}" ng-click="vm.toggleGShake()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.gShakeEnabled">
          <div>
            <div class="brsh-name">🌪️ Shake Strength</div>
            <div class="brsh-desc">How much the HUD moves.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0" max="18" step="1" ng-model="vm.settings.gShakePx"/>
            <div class="brsh-val">{{ vm.settings.gShakePx }} px</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.gShakeEnabled">
          <div>
            <div class="brsh-name">🏁 Shake Start Speed</div>
            <div class="brsh-desc">Stops the HUD shaking at 0 (Shorts-friendly).</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0" max="220" step="5" ng-model="vm.settings.gShakeStartSpeed"/>
            <div class="brsh-val">{{ vm.settings.gShakeStartSpeed }} {{ vm.settings.units }}</div>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">💥 Impact Punch</div>
            <div class="brsh-desc">Reliable hits, cooldown-based triggers.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.impactPunchEnabled}" ng-click="vm.toggleImpactPunch()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.impactPunchEnabled">
          <div>
            <div class="brsh-name">💥 Impact Sensitivity</div>
            <div class="brsh-desc">Lower = triggers more often.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0.2" max="6.0" step="0.1" ng-model="vm.settings.impactThreshold"/>
            <div class="brsh-val">{{ vm.settings.impactThreshold }} g/s</div>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🚨 Impact Red Flash</div>
            <div class="brsh-desc">Flashes even if Punch is OFF.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.impactFlashEnabled}" ng-click="vm.toggleImpactFlash()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.impactFlashEnabled">
          <div>
            <div class="brsh-name">🚨 Flash Strength</div>
            <div class="brsh-desc">More obvious for Shorts.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0.30" max="2.20" step="0.05" ng-model="vm.settings.impactFlashStrength"/>
            <div class="brsh-val">{{ vm.settings.impactFlashStrength }}</div>
          </div>
        </div>

        <div class="brsh-subsec">🔥 High-Speed FX</div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">💨 High Speed Streaks</div>
            <div class="brsh-desc">Adds subtle lines at high speed.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.streaksEnabled}" ng-click="vm.toggleStreaks()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.streaksEnabled">
          <div>
            <div class="brsh-name">💨 Streaks Start Speed</div>
            <div class="brsh-desc">When to enable streaks.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="40" max="500" step="5" ng-model="vm.settings.streaksStart"/>
            <div class="brsh-val">{{ vm.settings.streaksStart }} {{ vm.settings.units }}</div>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🔥 Heat Glow</div>
            <div class="brsh-desc">RED hot aura + strong glow at high speed.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.heatEnabled}" ng-click="vm.toggleHeat()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.heatEnabled">
          <div>
            <div class="brsh-name">🔥 Heat Start Speed</div>
            <div class="brsh-desc">Start heating at this speed.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="60" max="600" step="5" ng-model="vm.settings.heatStart"/>
            <div class="brsh-val">{{ vm.settings.heatStart }} {{ vm.settings.units }}</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.heatEnabled">
          <div>
            <div class="brsh-name">🔥 Heat Full Speed</div>
            <div class="brsh-desc">Full heat by this speed.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="80" max="900" step="5" ng-model="vm.settings.heatFull"/>
            <div class="brsh-val">{{ vm.settings.heatFull }} {{ vm.settings.units }}</div>
          </div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🌀 Fast Digit Blur</div>
            <div class="brsh-desc">Blur the last digit at very high speeds.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.speedBlurEnabled}" ng-click="vm.toggleSpeedBlur()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.speedBlurEnabled">
          <div>
            <div class="brsh-name">🌀 Blur Start Speed</div>
            <div class="brsh-desc">When the last digit starts blurring.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="60" max="900" step="5" ng-model="vm.settings.speedBlurStart"/>
            <div class="brsh-val">{{ vm.settings.speedBlurStart }} {{ vm.settings.units }}</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.speedBlurEnabled">
          <div>
            <div class="brsh-name">🌀 Blur Full Speed</div>
            <div class="brsh-desc">Max blur by this speed.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="80" max="1200" step="5" ng-model="vm.settings.speedBlurFull"/>
            <div class="brsh-val">{{ vm.settings.speedBlurFull }} {{ vm.settings.units }}</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.speedBlurEnabled">
          <div>
            <div class="brsh-name">🌀 Max Blur</div>
            <div class="brsh-desc">Strength of the blur on the last digit.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0" max="6.0" step="0.1" ng-model="vm.settings.speedBlurMaxPx"/>
            <div class="brsh-val">{{ vm.settings.speedBlurMaxPx }} px</div>
          </div>
        </div>

      </div>

      <div class="brsh-sec">
        <h3>💣 Speed Maintenance Challenge</h3>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">💣 Enable Challenge</div>
            <div class="brsh-desc">Starts after you reach the Start Speed.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.challengeEnabled}" ng-click="vm.toggleChallenge()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.challengeEnabled">
          <div>
            <div class="brsh-name">🎯 Start Speed</div>
            <div class="brsh-desc">Must stay above this speed or you fail.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="10" max="600" step="5" ng-model="vm.settings.challengeStartSpeed"/>
            <div class="brsh-val">{{ vm.settings.challengeStartSpeed }} {{ vm.settings.units }}</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.challengeEnabled">
          <div>
            <div class="brsh-name">⏳ Grace Time</div>
            <div class="brsh-desc">Seconds allowed below speed (countdown).</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0.2" max="6.0" step="0.1" ng-model="vm.settings.challengeGraceSeconds"/>
            <div class="brsh-val">{{ vm.settings.challengeGraceSeconds }} s</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.challengeEnabled">
          <div>
            <div class="brsh-name">💥 Explode on Fail</div>
            <div class="brsh-desc">Break car + fire for content. Reset vehicle to continue.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.challengeExplodeOnFail}" ng-click="vm.toggleExplodeOnFail()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.challengeEnabled">
          <div>
            <div class="brsh-name">🔒 Lock on Fail</div>
            <div class="brsh-desc">Keeps car undriveable until reset.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.challengeLockOnFail}" ng-click="vm.toggleLockOnFail()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.challengeEnabled">
          <div>
            <div class="brsh-name">🔥 UI Fire FX</div>
            <div class="brsh-desc">Size of on-screen flames (Shorts).</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0.4" max="2.2" step="0.05" ng-model="vm.settings.uiFireScale"/>
            <div class="brsh-val">{{ vm.settings.uiFireScale }}</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.challengeEnabled">
          <div>
            <div class="brsh-name">🔠 Countdown Size</div>
            <div class="brsh-desc">Make the danger countdown BIG.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="18" max="90" step="1" ng-model="vm.settings.dangerFontSize"/>
            <div class="brsh-val">{{ vm.settings.dangerFontSize }} px</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.challengeEnabled">
          <div>
            <div class="brsh-name">♻️ Reset Challenge</div>
            <div class="brsh-desc">Clears fail state. (Also: Alt+Numpad5)</div>
          </div>
          <button class="brsh-btn danger" ng-click="vm.resetChallenge()">Reset</button>
        </div>
      </div>

      <div class="brsh-sec">
        <h3>⚠️ Viewer Warning Text</h3>

        <div class="brsh-subsec">📣 Notice</div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">📣 Enable Warning</div>
            <div class="brsh-desc">Shows a viewer-facing label (always on).</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.noticeEnabled}" ng-click="vm.toggleNotice()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled">
          <div>
            <div class="brsh-name">🔤 Text</div>
            <div class="brsh-desc">What viewers see (leave empty for auto).</div>
          </div>
          <div><input class="brsh-input" type="text" ng-model="vm.settings.noticeCustomText" maxlength="80" placeholder="e.g. MUST STAY ABOVE 150 KM/H"/></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled">
          <div>
            <div class="brsh-name">🔠 Font Size</div>
            <div class="brsh-desc">Bigger for Shorts.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="10" max="64" step="1" ng-model="vm.settings.noticeFontSize"/>
            <div class="brsh-val">{{ vm.settings.noticeFontSize }} px</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled">
          <div>
            <div class="brsh-name">🚨 Show Icon</div>
            <div class="brsh-desc">Small warning icon next to text.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.noticeShowIcon}" ng-click="vm.toggleNoticeIcon()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-subsec" ng-if="vm.settings.noticeEnabled">❌ Fail Label</div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled">
          <div>
            <div class="brsh-name">❌ Fail Label Under Notice</div>
            <div class="brsh-desc">Shows a big FAILED! under the notice when the challenge fails.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.failLabelEnabled}" ng-click="vm.toggleFailLabel()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled && vm.settings.failLabelEnabled">
          <div>
            <div class="brsh-name">❌ Fail Label Size</div>
            <div class="brsh-desc">Bigger is better for Shorts.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="12" max="90" step="1" ng-model="vm.settings.failLabelFontSize"/>
            <div class="brsh-val">{{ vm.settings.failLabelFontSize }} px</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled && vm.settings.failLabelEnabled">
          <div>
            <div class="brsh-name">🎨 Fail Label Color</div>
            <div class="brsh-desc">Hex color (example: #ff3c3c).</div>
          </div>
          <div><input class="brsh-input" type="text" ng-model="vm.settings.failLabelColor" maxlength="16" placeholder="#ff3c3c"/></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled && vm.settings.failLabelEnabled">
          <div>
            <div class="brsh-name">🌑 Fail Label Shadow</div>
            <div class="brsh-desc">Extra readability behind FAILED!</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.failLabelShadowEnabled}" ng-click="vm.toggleFailLabelShadow()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled && vm.settings.failLabelEnabled && vm.settings.failLabelShadowEnabled">
          <div>
            <div class="brsh-name">🌑 Fail Shadow Controls</div>
            <div class="brsh-desc">Blur / opacity / offsets.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="0" max="80" step="1" ng-model="vm.settings.failLabelShadowBlur"/><div class="brsh-val">Blur: {{ vm.settings.failLabelShadowBlur }} px</div>
            <input type="range" min="-40" max="40" step="1" ng-model="vm.settings.failLabelShadowX"/><div class="brsh-val">Offset X: {{ vm.settings.failLabelShadowX }} px</div>
            <input type="range" min="-40" max="40" step="1" ng-model="vm.settings.failLabelShadowY"/><div class="brsh-val">Offset Y: {{ vm.settings.failLabelShadowY }} px</div>
            <input type="range" min="0" max="1" step="0.05" ng-model="vm.settings.failLabelShadowOpacity"/><div class="brsh-val">Opacity: {{ vm.settings.failLabelShadowOpacity }}</div>
          </div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled && vm.settings.failLabelEnabled">
          <div>
            <div class="brsh-name">✏️ Fail Label Outline</div>
            <div class="brsh-desc">Optional outline stroke on FAILED!</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.failLabelOutlineEnabled}" ng-click="vm.toggleFailLabelOutline()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row" ng-if="vm.settings.noticeEnabled && vm.settings.failLabelEnabled && vm.settings.failLabelOutlineEnabled">
          <div>
            <div class="brsh-name">✏️ Fail Outline Controls</div>
            <div class="brsh-desc">Thickness + opacity + color.</div>
          </div>
          <div class="brsh-slider">
            <input type="range" min="1" max="10" step="1" ng-model="vm.settings.failLabelOutlineSize"/><div class="brsh-val">Size: {{ vm.settings.failLabelOutlineSize }} px</div>
            <input type="range" min="0" max="1" step="0.05" ng-model="vm.settings.failLabelOutlineOpacity"/><div class="brsh-val">Opacity: {{ vm.settings.failLabelOutlineOpacity }}</div>
            <div class="brsh-seg">
              <button ng-class="{active: vm.settings.failLabelOutlineColor==='dark'}" ng-click="vm.setFailLabelOutlineColor('dark')">Dark</button>
              <button ng-class="{active: vm.settings.failLabelOutlineColor==='light'}" ng-click="vm.setFailLabelOutlineColor('light')">Light</button>
            </div>
          </div>
        </div>

      </div>

      <div class="brsh-sec">
        <h3>🛠️ Utilities</h3>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">⚙️ Show Settings Button</div>
            <div class="brsh-desc">Small ⚙ button (fallback). Disable for recordings.</div>
          </div>
          <div class="brsh-switch" ng-class="{on: vm.settings.showSettingsButton}" ng-click="vm.toggleSettingsButton()"><div class="thumb"></div></div>
        </div>

        <div class="brsh-row">
          <div>
            <div class="brsh-name">🧼 Restore Defaults</div>
            <div class="brsh-desc">Reset all settings to defaults.</div>
          </div>
          <button class="brsh-btn danger" ng-click="vm.restoreDefaults()">Defaults</button>
        </div>
      </div>

    </div>

    <div class="brsh-resize" ng-mousedown="vm.ui.resizeStart($event)"></div>
  </div>

</div>
        `,
        link: function (scope, element) {
          var LS = "BeamRoyal_SpeedHUD_Settings_v10";
          var SETTINGS_VERSION = 12;

          function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
          function safeParse(json, fallback) { try { return JSON.parse(json); } catch (e) { return fallback; } }
          function fmtFixed(n, decimals) {
            n = (isNaN(n) || n == null) ? 0 : n;
            return Number(n).toFixed(decimals);
          }

          function normHexColor(str, fallback) {
            fallback = fallback || "#ffffff";
            if (typeof str !== "string") return fallback;
            var s = str.trim();
            if (!s) return fallback;
            if (!/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(s)) return fallback;
            // Normalize short hex -> full hex
            if (s.length === 4) {
              s = "#" + s[1] + s[1] + s[2] + s[2] + s[3] + s[3];
            }
            return s.toLowerCase();
          }

          function rgbaFromHex(hex, alpha) {
            var h = normHexColor(hex, "#ffffff").slice(1);
            var r = parseInt(h.slice(0, 2), 16) || 255;
            var g = parseInt(h.slice(2, 4), 16) || 255;
            var b = parseInt(h.slice(4, 6), 16) || 255;
            var a = clamp(+alpha || 1, 0, 1);
            return "rgba(" + r + "," + g + "," + b + "," + a.toFixed(3) + ")";
          }

          function engineLua(code) {
            try {
              if (window.bngApi && typeof window.bngApi.engineLua === "function") { window.bngApi.engineLua(code); return true; }
              if (window.bridge && typeof window.bridge.sendGameEngineLua === "function") { window.bridge.sendGameEngineLua(code); return true; }
            } catch (e) {}
            $log.error("[BeamRoyalSpeedHUDMod] Cannot call engine Lua from UI.");
            return false;
          }

          var DEFAULTS = {
            settingsSchemaVersion: SETTINGS_VERSION,
            hudVisible: true,

            units: "kmh",
            decimals: 0,
            showUnit: true,

            // speed reference
            speedSource: "wheel",       // "wheel" | "air" | "dynamic"
            speedSourceBlendMs: 400,     // 300-500ms recommended

            // creator: target speed lock
            speedLockEnabled: false,
            speedLockTargetMS: 27.7777777778, // 100 km/h
            fontSize: 140,
            textOpacity: 1.0,
            hudColor: "#ffffff",
            unitScale: 0.22,

            // Instant Acceleration (clean speed set via thrusters.applyVelocity)
            instantAccelEnabled: false,
            instantAccelMode: "set",            // "set" | "add"
            instantAccelSpeedMS: 27.7777777778, // 100 km/h
            instantAccelDuration: 0.20,          // seconds
            instantAccelRamp: 0.00,              // seconds
            instantAccelInvertDir: false,
            instantAccelBannerEnabled: true,
            dsePopupDontShowAgain: false,

            shadowEnabled: true,
            shadowBlur: 22,
            shadowX: 0,
            shadowY: 12,
            shadowOpacity: 0.65,

            outlineEnabled: false,
            outlineSize: 2,
            outlineOpacity: 0.85,
            outlineColor: "dark",

            animMode: "bump",
            animDurationMs: 240,

            hudBox: { x: null, y: null, w: 520, h: 220 },
            noticeBox: { x: null, y: null },

            panel: { x: 100, y: 90, w: 680, h: 900 },

            gShakeEnabled: false,
            gShakePx: 8,
            gShakeStartSpeed: 25,

            impactPunchEnabled: false,
            impactThreshold: 1.2,

            impactFlashEnabled: true,
            impactFlashStrength: 1.0,

            streaksEnabled: true,
            streaksStart: 160,

            heatEnabled: true,
            heatStart: 180,
            heatFull: 320,

            speedBlurEnabled: true,
            speedBlurStart: 375,
            speedBlurFull: 515,
            speedBlurMaxPx: 1.9,

            challengeEnabled: false,
            challengeStartSpeed: 100,
            challengeGraceSeconds: 2.0,
            challengeExplodeOnFail: true,
            challengeLockOnFail: true,

            uiFireScale: 1.15,
            dangerFontSize: 44,

            noticeEnabled: false,
            noticeCustomText: "",
            noticeFontSize: 18,
            noticeShowIcon: true,

            failLabelEnabled: true,
            failLabelFontSize: 34,
            failLabelColor: "#ff3c3c",

            failLabelShadowEnabled: true,
            failLabelShadowBlur: 18,
            failLabelShadowX: 0,
            failLabelShadowY: 10,
            failLabelShadowOpacity: 0.80,

            failLabelOutlineEnabled: false,
            failLabelOutlineSize: 2,
            failLabelOutlineOpacity: 0.85,
            failLabelOutlineColor: "dark",

            showSettingsButton: true
          };

          var settings = angular.extend({}, DEFAULTS, safeParse(localStorage.getItem(LS), {}));
          settings.panel = settings.panel || DEFAULTS.panel;
          settings.hudBox = settings.hudBox || DEFAULTS.hudBox;
          settings.noticeBox = settings.noticeBox || DEFAULTS.noticeBox;

          function applySettingsMigration(target) {
            var version = +target.settingsSchemaVersion || 0;

            if (version < SETTINGS_VERSION) {
              if (version < 11) {
                target.gShakeEnabled = false;
                target.impactPunchEnabled = false;
                target.noticeEnabled = false;
                target.speedBlurStart = 375;
                target.speedBlurFull = 515;
                target.speedBlurMaxPx = 1.9;
                if (typeof target.instantAccelBannerEnabled !== "boolean") target.instantAccelBannerEnabled = true;
              }
              if (version < 12) {
                if (typeof target.dsePopupDontShowAgain !== "boolean") target.dsePopupDontShowAgain = false;
              }
            }

            target.settingsSchemaVersion = SETTINGS_VERSION;
          }

          applySettingsMigration(settings);

          function ensureDefaultPositions() {
            var w = window.innerWidth || 1920;
            var h = window.innerHeight || 1080;

            if (settings.hudBox.x == null || settings.hudBox.y == null) {
              settings.hudBox.x = Math.round(w * 0.5 - (settings.hudBox.w || 520) * 0.5);
              settings.hudBox.y = Math.round(h * 0.72);
            }
            if (settings.noticeBox.x == null || settings.noticeBox.y == null) {
              settings.noticeBox.x = Math.round(w * 0.5 - 220);
              settings.noticeBox.y = Math.round(h * 0.63);
            }
          }

          function normalize() {
            settings.decimals = clamp(+settings.decimals || 0, 0, 2);
            settings.fontSize = clamp(+settings.fontSize || 140, 28, 260);
            settings.textOpacity = clamp(+settings.textOpacity || 1, 0.2, 1);
            // HUD color (hex)
            if (typeof settings.hudColor !== "string") settings.hudColor = "#ffffff";
            settings.hudColor = (settings.hudColor || "").trim();
            if (!settings.hudColor) settings.hudColor = "#ffffff";
            if (!/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(settings.hudColor)) settings.hudColor = "#ffffff";
            settings.unitScale = clamp(+settings.unitScale || 0.22, 0.12, 0.45);

            settings.shadowBlur = clamp(+settings.shadowBlur || 22, 0, 80);
            settings.shadowX = clamp(+settings.shadowX || 0, -40, 40);
            settings.shadowY = clamp(+settings.shadowY || 12, -40, 40);
            settings.shadowOpacity = clamp(+settings.shadowOpacity || 0.65, 0, 1);

            settings.outlineSize = clamp(+settings.outlineSize || 2, 1, 10);
            settings.outlineOpacity = clamp(+settings.outlineOpacity || 0.85, 0, 1);
            if (settings.outlineColor !== "light") settings.outlineColor = "dark";

            if (settings.units !== "mph") settings.units = "kmh";

            // speed reference / creator tools
            if (settings.speedSource !== "air" && settings.speedSource !== "dynamic") settings.speedSource = "wheel";
            settings.speedSourceBlendMs = clamp(+settings.speedSourceBlendMs || 400, 60, 1500);

            if (typeof settings.speedLockEnabled !== "boolean") settings.speedLockEnabled = false;
            settings.speedLockTargetMS = clamp(+settings.speedLockTargetMS || 0, 0, 600);

            // Instant Acceleration (thrusters.applyVelocity)
            if (typeof settings.instantAccelEnabled !== "boolean") settings.instantAccelEnabled = false;
            if (settings.instantAccelMode !== 'add') settings.instantAccelMode = 'set';
            settings.instantAccelSpeedMS = clamp(+settings.instantAccelSpeedMS || 0, 0, 5000);
            settings.instantAccelDuration = clamp(+settings.instantAccelDuration || 0.20, 0, 10.0);
            settings.instantAccelRamp = clamp(+settings.instantAccelRamp || 0, 0, 2.0);
            if (typeof settings.instantAccelInvertDir !== "boolean") settings.instantAccelInvertDir = false;
            if (typeof settings.instantAccelBannerEnabled !== "boolean") settings.instantAccelBannerEnabled = true;
            if (typeof settings.dsePopupDontShowAgain !== "boolean") settings.dsePopupDontShowAgain = false;

            settings.animDurationMs = clamp(+settings.animDurationMs || 240, 60, 900);
            if (settings.animMode !== "slide" && settings.animMode !== "none") settings.animMode = "bump";

            settings.gShakePx = clamp(+settings.gShakePx || 0, 0, 18);
            settings.gShakeStartSpeed = clamp(+settings.gShakeStartSpeed || 0, 0, 220);

            settings.impactThreshold = clamp(+settings.impactThreshold || 1.2, 0.2, 6.0);
            settings.impactFlashStrength = clamp(+settings.impactFlashStrength || 1.0, 0.30, 2.20);

            settings.streaksStart = clamp(+settings.streaksStart || 160, 40, 500);
            settings.heatStart = clamp(+settings.heatStart || 180, 60, 600);
            settings.heatFull = clamp(+settings.heatFull || 320, 80, 900);
            if (settings.heatFull < settings.heatStart + 10) settings.heatFull = settings.heatStart + 10;

            settings.speedBlurStart = clamp(+settings.speedBlurStart || 375, 60, 900);
            settings.speedBlurFull = clamp(+settings.speedBlurFull || 515, 80, 1200);
            if (settings.speedBlurFull < settings.speedBlurStart + 10) settings.speedBlurFull = settings.speedBlurStart + 10;
            settings.speedBlurMaxPx = clamp(+settings.speedBlurMaxPx || 1.9, 0, 6.0);

            settings.challengeStartSpeed = clamp(+settings.challengeStartSpeed || 100, 10, 600);
            settings.challengeGraceSeconds = clamp(+settings.challengeGraceSeconds || 2.0, 0.2, 6.0);

            settings.uiFireScale = clamp(+settings.uiFireScale || 1.0, 0.4, 2.2);
            settings.dangerFontSize = clamp(+settings.dangerFontSize || 44, 18, 90);

            settings.noticeFontSize = clamp(+settings.noticeFontSize || 18, 10, 64);
            if (typeof settings.noticeCustomText !== "string") settings.noticeCustomText = "";

            settings.failLabelFontSize = clamp(+settings.failLabelFontSize || 34, 12, 90);
            if (typeof settings.failLabelColor !== "string") settings.failLabelColor = "#ff3c3c";

            settings.failLabelShadowBlur = clamp(+settings.failLabelShadowBlur || 18, 0, 80);
            settings.failLabelShadowX = clamp(+settings.failLabelShadowX || 0, -40, 40);
            settings.failLabelShadowY = clamp(+settings.failLabelShadowY || 10, -40, 40);
            settings.failLabelShadowOpacity = clamp(+settings.failLabelShadowOpacity || 0.80, 0, 1);

            settings.failLabelOutlineSize = clamp(+settings.failLabelOutlineSize || 2, 1, 10);
            settings.failLabelOutlineOpacity = clamp(+settings.failLabelOutlineOpacity || 0.85, 0, 1);
            if (settings.failLabelOutlineColor !== "light") settings.failLabelOutlineColor = "dark";

            if (typeof settings.showSettingsButton !== "boolean") settings.showSettingsButton = true;

            ensureDefaultPositions();
          }

          normalize();

          var vm = (scope.vm = {
            settings: settings,

            // A small curated palette (similar idea to the Text Overlay HUD).
            hudColorPalette: [
              "#ffffff",
              "#000000",
              "#ff3b30",
              "#ffcc00",
              "#34c759",
              "#0a84ff",
              "#5e5ce6",
              "#00e5ff"
            ],

            ui: {
              settingsOpen: false,
              panelStyle: {},

              hudStyle: {},
              hudEdit: false,

              noticeStyle: {},
              noticeTextStyle: {},
              noticeEdit: false,
              noticeVisible: true,
              noticeText: "",

              failLabelVisible: false,
              failLabelPop: false,
              failLabelStyle: {},

              speedTextMain: "",
              speedTextTail: "0",
              speedTailStyle: {},

              // Low speed stability (prevents 0↔1 flicker)
              zeroLatch: true,

              unitText: "km/h",

              // creator tools
              speedLockTargetDisplay: "",
              instantAccelSpeedDisplay: "",
              speedStyle: {},
              unitStyle: {},
              speedWrapStyle: {},

              animClass: "",
              impactPunch: false,
              impactFlash: false,

              heatOn: false,
              heatAuraStyle: {},
              heatAuraCrit: false,

              streaksOn: false,

              fireOn: false,
              fireStyle: {},

              dangerVisible: false,
              dangerCritical: false,
              dangerText: "",
              dangerSubText: "",
              dangerStyle: {},
              dangerSubStyle: {},

              boostBannerVisible: false,
              boostBannerShow: false,
              boostBannerText: "",

              dsePopupVisible: false,
              dsePopupLastVehicleKey: null,

              failFlash: false,
              failStyle: {},

              dragStart: function () {},
              resizeStart: function () {},
              hudDragStart: function () {},
              noticeDragStart: function () {}
            },

            toggleSettings: function () {
              vm.ui.settingsOpen = !vm.ui.settingsOpen;
              if (vm.ui.settingsOpen) applyPanelStyle();
              saveDebounced();
            },

            toggleSettingsButton: function () {
              settings.showSettingsButton = !settings.showSettingsButton;
              saveDebounced();
            },

            restoreDefaults: function () {
              Object.keys(DEFAULTS).forEach(function (k) {
                settings[k] = (typeof DEFAULTS[k] === "object")
                  ? JSON.parse(JSON.stringify(DEFAULTS[k]))
                  : DEFAULTS[k];
              });
              normalize();
              applyHudStyle();
              applyNoticeStyle();
              refreshUnitText();
              refreshSpeedLockTargetDisplay();
              refreshInstantAccelSpeedDisplay();
              refreshTextStyles("");
              refreshFailLabelStyles();
              applyPanelStyle();
              applyFireStyle();
              pushLogicSettingsDebounced();
              saveDebounced();
            },

            toggleHudVisible: function () { settings.hudVisible = !settings.hudVisible; saveDebounced(); },
            setUnits: function (u) {
              settings.units = u;
              normalize();
              refreshUnitText();
              refreshSpeedLockTargetDisplay();
              refreshInstantAccelSpeedDisplay();
              pushLogicSettingsDebounced();
              saveDebounced();
            },
            setDecimals: function (d) { settings.decimals = +d; normalize(); updateSpeedText(lastSpeedMS); saveDebounced(); },
            toggleShowUnit: function () { settings.showUnit = !settings.showUnit; saveDebounced(); },

            // speed reference (wheel/air/dynamic)
            setSpeedSource: function (src) {
              settings.speedSource = src;
              normalize();
              pushLogicSettingsDebounced();
              saveDebounced();
            },
            setSpeedSourceBlendMs: function (ms) {
              settings.speedSourceBlendMs = +ms;
              normalize();
              pushLogicSettingsDebounced();
              saveDebounced();
            },

            // creator: target speed lock
            toggleSpeedLock: function () {
              settings.speedLockEnabled = !settings.speedLockEnabled;
              pushLogicSettingsDebounced();
              saveDebounced();
            },
            onSpeedLockTargetInput: function () {
              var ms = parseSpeedInput(vm.ui.speedLockTargetDisplay);
              if (ms == null) return;
              settings.speedLockTargetMS = ms;
              normalize();
              pushLogicSettingsDebounced();
              saveDebounced();
            },
            onSpeedLockTargetBlur: function () {
              refreshSpeedLockTargetDisplay();
              saveDebounced();
            },

            // HUD color
            setHudColor: function (c) {
              settings.hudColor = c;
              normalize();
              refreshTextStyles(lastGlowShadow);
              saveDebounced();
            },

            // Instant Acceleration
            toggleInstantAccel: function () {
              settings.instantAccelEnabled = !settings.instantAccelEnabled;
              if (!settings.instantAccelEnabled) vm.ui.dsePopupVisible = false;
              pushLogicSettingsDebounced();
              saveDebounced();
            },
            setInstantAccelMode: function (m) {
              settings.instantAccelMode = m;
              normalize();
              pushLogicSettingsDebounced();
              saveDebounced();
            },
            toggleInstantAccelInvertDir: function () {
              settings.instantAccelInvertDir = !settings.instantAccelInvertDir;
              pushLogicSettingsDebounced();
              saveDebounced();
            },
            toggleInstantAccelBanner: function () {
              settings.instantAccelBannerEnabled = !settings.instantAccelBannerEnabled;
              saveDebounced();
            },
            onDsePopupPrefChanged: function () {
              saveDebounced();
            },
            closeDsePopup: function () {
              vm.ui.dsePopupVisible = false;
              saveDebounced();
            },
            onInstantAccelSpeedInput: function () {
              var ms = parseSpeedInput(vm.ui.instantAccelSpeedDisplay);
              if (ms == null) return;
              settings.instantAccelSpeedMS = ms;
              normalize();
              pushLogicSettingsDebounced();
              saveDebounced();
            },
            onInstantAccelSpeedBlur: function () {
              refreshInstantAccelSpeedDisplay();
              saveDebounced();
            },

            toggleShadow: function () { settings.shadowEnabled = !settings.shadowEnabled; refreshTextStyles(lastGlowShadow); applyNoticeStyle(); saveDebounced(); },
            toggleOutline: function () { settings.outlineEnabled = !settings.outlineEnabled; refreshTextStyles(lastGlowShadow); applyNoticeStyle(); saveDebounced(); },
            setOutlineColor: function (c) { settings.outlineColor = c; refreshTextStyles(lastGlowShadow); applyNoticeStyle(); saveDebounced(); },

            toggleHudEdit: function () { vm.ui.hudEdit = !vm.ui.hudEdit; if (vm.ui.hudEdit) vm.ui.settingsOpen = true; saveDebounced(); },
            toggleNoticeEdit: function () { vm.ui.noticeEdit = !vm.ui.noticeEdit; if (vm.ui.noticeEdit) vm.ui.settingsOpen = true; saveDebounced(); },
            snapHud: function (where) { snapHud(where); saveDebounced(); },
            resetPositions: function () { resetPositions(); saveDebounced(); },

            toggleGShake: function () { settings.gShakeEnabled = !settings.gShakeEnabled; saveDebounced(); },
            toggleImpactPunch: function () { settings.impactPunchEnabled = !settings.impactPunchEnabled; saveDebounced(); },
            toggleImpactFlash: function () { settings.impactFlashEnabled = !settings.impactFlashEnabled; saveDebounced(); },
            toggleStreaks: function () { settings.streaksEnabled = !settings.streaksEnabled; saveDebounced(); },
            toggleHeat: function () { settings.heatEnabled = !settings.heatEnabled; saveDebounced(); },
            toggleSpeedBlur: function () { settings.speedBlurEnabled = !settings.speedBlurEnabled; saveDebounced(); },

            toggleChallenge: function () { settings.challengeEnabled = !settings.challengeEnabled; resetLocalChallengeIfNeeded(true); pushLogicSettingsDebounced(); saveDebounced(); },
            toggleExplodeOnFail: function () { settings.challengeExplodeOnFail = !settings.challengeExplodeOnFail; pushLogicSettingsDebounced(); saveDebounced(); },
            toggleLockOnFail: function () { settings.challengeLockOnFail = !settings.challengeLockOnFail; pushLogicSettingsDebounced(); saveDebounced(); },
            resetChallenge: function () {
              engineLua("extensions.load('beamroyaleSpeedHUD'); if extensions.beamroyaleSpeedHUD and extensions.beamroyaleSpeedHUD.resetChallenge then extensions.beamroyaleSpeedHUD.resetChallenge() end");
              resetLocalChallengeIfNeeded(false);
              vm.ui.failFlash = false;
            },

            toggleNotice: function () { settings.noticeEnabled = !settings.noticeEnabled; applyNoticeStyle(); saveDebounced(); },
            toggleNoticeIcon: function () { settings.noticeShowIcon = !settings.noticeShowIcon; applyNoticeStyle(); saveDebounced(); },

            toggleFailLabel: function () { settings.failLabelEnabled = !settings.failLabelEnabled; refreshFailLabelStyles(); saveDebounced(); },
            toggleFailLabelShadow: function () { settings.failLabelShadowEnabled = !settings.failLabelShadowEnabled; refreshFailLabelStyles(); saveDebounced(); },
            toggleFailLabelOutline: function () { settings.failLabelOutlineEnabled = !settings.failLabelOutlineEnabled; refreshFailLabelStyles(); saveDebounced(); },
            setFailLabelOutlineColor: function (c) { settings.failLabelOutlineColor = c; refreshFailLabelStyles(); saveDebounced(); }
          });

          var BRSH_HK_KEY = "__BRSH_SPEEDHUD_HK__";
          var brshHK = window[BRSH_HK_KEY];
          if (!brshHK) {
            brshHK = window[BRSH_HK_KEY] = {
              installed: false,
              lastT: 0,
              handlers: [],
              listener: null
            };
          }

          function brshIsEditableTarget(el) {
            if (!el) return false;
            var tag = (el.tagName || "").toLowerCase();
            if (tag === "input" || tag === "textarea" || tag === "select") return true;
            if (el.isContentEditable) return true;
            return false;
          }

          function brshIsHotkeyEvent(e) {
            if (!e) return false;
            if (!e.altKey) return false;
            if (e.ctrlKey || e.shiftKey || e.metaKey) return false;

            var code = e.code || "";
            var key = e.key || "";
            var kc = e.keyCode || e.which || 0;
            var loc = e.location || 0;

            var isNumpad4 =
              code === "Numpad4" ||
              kc === 100 ||
              (loc === 3 && (key === "4" || key === "ArrowLeft" || kc === 37));

            var isDigit4 =
              code === "Digit4" ||
              (key === "4" && loc !== 3);

            return isNumpad4 || isDigit4;
          }

          function brshInstallGlobalHotkey() {
            if (brshHK.installed) return;

            brshHK.listener = function (e) {
              try {
                if (!brshIsHotkeyEvent(e)) return;
                if (brshIsEditableTarget(e.target)) return;
                if (e.repeat) return;

                var now = Date.now();
                if (now - brshHK.lastT < 220) return;
                brshHK.lastT = now;

                if (typeof e.preventDefault === "function") e.preventDefault();
                if (typeof e.stopImmediatePropagation === "function") e.stopImmediatePropagation();
                if (typeof e.stopPropagation === "function") e.stopPropagation();

                var h = brshHK.handlers.length ? brshHK.handlers[brshHK.handlers.length - 1] : null;
                if (h && typeof h.toggle === "function") h.toggle();
              } catch (err) {}
            };

            try {
              window.addEventListener("keydown", brshHK.listener, true);
              brshHK.installed = true;
            } catch (e) {}
          }

          function brshRegisterInstance(toggleFn) {
            var id = "brsh_" + Math.random().toString(36).slice(2);
            brshHK.handlers.push({ id: id, toggle: toggleFn });

            if (brshHK.handlers.length > 16) {
              brshHK.handlers = brshHK.handlers.slice(-8);
            }

            return function unregister() {
              try {
                brshHK.handlers = (brshHK.handlers || []).filter(function (x) { return x && x.id !== id; });
              } catch (e) {}
            };
          }

          brshInstallGlobalHotkey();
          var unregisterHotkey = brshRegisterInstance(function () {
            try { scope.$applyAsync(function () { vm.toggleSettings(); }); } catch (e) {}
          });

          scope.$on("BeamRoyalSpeedHUDToggleSettings", function () {
            var now = Date.now();
            if (now - brshHK.lastT < 220) return;
            brshHK.lastT = now;
            scope.$applyAsync(function () { vm.toggleSettings(); });
          });

          function saveDebounced() {
            if (saveDebounced._t) $timeout.cancel(saveDebounced._t);
            saveDebounced._t = $timeout(function () {
              localStorage.setItem(LS, JSON.stringify(settings));
            }, 140);
          }

          // Ensure the pinned top section does NOT overlap the scroll body.
          // We measure header + pinned heights and store them as CSS variables on the panel.
          function applyPanelLayout() {
            $timeout(function () {
              try {
                var rootEl = (element && element[0]) ? element[0] : null;
                if (!rootEl) return;

                var panelEl = rootEl.querySelector(".brsh-settings");
                if (!panelEl) return;

                var headerEl = panelEl.querySelector(".brsh-settingsHeader");
                var pinnedEl = panelEl.querySelector(".brsh-pinnedTop");

                var headerH = headerEl ? headerEl.offsetHeight : 120;
                var pinnedH = pinnedEl ? pinnedEl.offsetHeight : 0;

                panelEl.style.setProperty("--brshHeaderH", headerH + "px");
                panelEl.style.setProperty("--brshPinnedH", pinnedH + "px");
              } catch (e) {}
            }, 0, false);
          }

          function applyPanelStyle() {
            var p = settings.panel;
            p.x = clamp(+p.x || 100, 0, (window.innerWidth || 1920) - 240);
            p.y = clamp(+p.y || 90, 0, (window.innerHeight || 1080) - 140);
            p.w = clamp(+p.w || 680, 420, (window.innerWidth || 1920) - p.x);
            p.h = clamp(+p.h || 900, 340, (window.innerHeight || 1080) - p.y);
            vm.ui.panelStyle = { left: p.x + "px", top: p.y + "px", width: p.w + "px", height: p.h + "px" };
            applyPanelLayout();
          }

          function applyHudStyle() {
            var b = settings.hudBox;
            var w = window.innerWidth || 1920;
            var h = window.innerHeight || 1080;

            b.w = clamp(+b.w || 520, 220, 900);
            b.h = clamp(+b.h || 220, 120, 520);

            b.x = clamp(+b.x || 0, 0, w - 40);
            b.y = clamp(+b.y || 0, 0, h - 40);

            vm.ui.hudStyle = angular.extend({}, vm.ui.hudStyle, {
              left: b.x + "px", top: b.y + "px", width: b.w + "px", height: b.h + "px"
            });
          }

          function buildTextShadow() {
            var parts = [];

            if (settings.shadowEnabled) {
              parts.push(
                (settings.shadowX || 0) + "px " +
                (settings.shadowY || 0) + "px " +
                (settings.shadowBlur || 0) + "px rgba(0,0,0," + (settings.shadowOpacity || 0) + ")"
              );
            }

            if (settings.outlineEnabled) {
              var o = clamp(+settings.outlineSize || 2, 1, 12);
              var col = (settings.outlineColor === "light")
                ? "rgba(255,255,255," + (settings.outlineOpacity || 0.8) + ")"
                : "rgba(0,0,0," + (settings.outlineOpacity || 0.8) + ")";
              parts.push(
                o + "px 0px 0 " + col,
                (-o) + "px 0px 0 " + col,
                "0px " + o + "px 0 " + col,
                "0px " + (-o) + "px 0 " + col,
                o + "px " + o + "px 0 " + col,
                (-o) + "px " + o + "px 0 " + col,
                o + "px " + (-o) + "px 0 " + col,
                (-o) + "px " + (-o) + "px 0 " + col
              );
            }

            return parts.join(", ");
          }

          function applyNoticeStyle() {
            var b = settings.noticeBox;
            var w = window.innerWidth || 1920;
            var h = window.innerHeight || 1080;

            b.x = clamp(+b.x || 0, 0, w - 60);
            b.y = clamp(+b.y || 0, 0, h - 60);

            vm.ui.noticeStyle = { left: b.x + "px", top: b.y + "px" };
            vm.ui.noticeTextStyle = angular.extend({}, vm.ui.noticeTextStyle, {
              fontSize: settings.noticeFontSize + "px",
              textShadow: buildTextShadow()
            });
          }

          function snapHud(where) {
            var w = window.innerWidth || 1920;
            var h = window.innerHeight || 1080;
            var b = settings.hudBox;

            b.w = clamp(+b.w || 520, 220, 900);
            b.h = clamp(+b.h || 220, 120, 520);

            b.x = Math.round(w * 0.5 - b.w * 0.5);
            if (where === "top") b.y = Math.round(h * 0.08);
            else if (where === "center") b.y = Math.round(h * 0.5 - b.h * 0.5);
            else b.y = Math.round(h * 0.72);

            applyHudStyle();

            settings.noticeBox.x = Math.round(w * 0.5 - 220);
            if (where === "top") settings.noticeBox.y = Math.round(h * 0.20);
            else if (where === "center") settings.noticeBox.y = Math.round(h * 0.18);
            else settings.noticeBox.y = Math.round(h * 0.63);
            applyNoticeStyle();
          }

          function resetPositions() {
            settings.hudBox.x = null;
            settings.hudBox.y = null;
            settings.noticeBox.x = null;
            settings.noticeBox.y = null;

            ensureDefaultPositions();
            applyHudStyle();
            applyNoticeStyle();
          }

          var lastGlowShadow = "";

          function refreshTextStyles(extraGlow) {
            try {
              element[0].style.setProperty("--brsh-animDur", (settings.animDurationMs || 240) + "ms");
              element[0].style.setProperty("--brsh-flashStrength", String(settings.impactFlashStrength || 1));
            } catch (e) {}

            var opacity = clamp(+settings.textOpacity || 1, 0.2, 1);
            var baseHex = normHexColor(settings.hudColor, "#ffffff");
            var baseShadow = buildTextShadow();
            var glow = extraGlow || "";

            lastGlowShadow = glow;

            var textShadow = baseShadow;
            if (glow) textShadow = (textShadow ? (textShadow + ", " + glow) : glow);

            vm.ui.speedStyle = {
              fontSize: settings.fontSize + "px",
              fontWeight: 950,
              color: rgbaFromHex(baseHex, opacity),
              textShadow: textShadow
            };

            var unitSize = Math.max(10, Math.round(settings.fontSize * (settings.unitScale || 0.22)));
            vm.ui.unitStyle = {
              fontSize: unitSize + "px",
              fontWeight: 850,
              color: rgbaFromHex(baseHex, Math.max(0.15, opacity * 0.85)),
              textShadow: textShadow
            };

            vm.ui.speedWrapStyle = { gap: "14px" };

            vm.ui.noticeTextStyle = angular.extend({}, vm.ui.noticeTextStyle, {
              textShadow: baseShadow
            });

            vm.ui.dangerStyle = { fontSize: settings.dangerFontSize + "px" };
            vm.ui.dangerSubStyle = { fontSize: Math.max(12, Math.round(settings.dangerFontSize * 0.32)) + "px" };
          }

          function buildFailLabelShadow() {
            var parts = [];

            if (settings.failLabelShadowEnabled) {
              parts.push(
                (settings.failLabelShadowX || 0) + "px " +
                (settings.failLabelShadowY || 0) + "px " +
                (settings.failLabelShadowBlur || 0) + "px rgba(0,0,0," + (settings.failLabelShadowOpacity || 0) + ")"
              );
            }

            if (settings.failLabelOutlineEnabled) {
              var o = clamp(+settings.failLabelOutlineSize || 2, 1, 12);
              var col = (settings.failLabelOutlineColor === "light")
                ? "rgba(255,255,255," + (settings.failLabelOutlineOpacity || 0.8) + ")"
                : "rgba(0,0,0," + (settings.failLabelOutlineOpacity || 0.8) + ")";
              parts.push(
                o + "px 0px 0 " + col,
                (-o) + "px 0px 0 " + col,
                "0px " + o + "px 0 " + col,
                "0px " + (-o) + "px 0 " + col,
                o + "px " + o + "px 0 " + col,
                (-o) + "px " + o + "px 0 " + col,
                o + "px " + (-o) + "px 0 " + col,
                (-o) + "px " + (-o) + "px 0 " + col
              );
            }

            return parts.join(", ");
          }

          function refreshFailLabelStyles() {
            var shadow = buildFailLabelShadow();
            var col = (settings.failLabelColor || "#ff3c3c").trim();
            if (!col) col = "#ff3c3c";

            vm.ui.failLabelStyle = {
              fontSize: settings.failLabelFontSize + "px",
              color: col,
              textShadow: shadow
            };
          }

          function toDisplay(speedMS) {
            if (settings.units === "mph") return speedMS * 2.2369362920544;
            return speedMS * 3.6;
          }

          function fromDisplay(speedDisplay) {
            var v = Math.max(0, +speedDisplay || 0);
            if (settings.units === "mph") return v / 2.2369362920544;
            return v / 3.6;
          }

          // Parse inputs like:
          //   "100"        -> uses current Units setting
          //   "100 km/h"   -> km/h
          //   "62 mph"     -> mph
          //   "27.78 m/s"  -> m/s
          function parseSpeedInput(str) {
            if (str == null) return null;
            var s = ("" + str).trim().toLowerCase();
            if (!s) return null;

            // allow comma decimals
            s = s.replace(/,/g, ".");

            // extract number + optional unit suffix
            var m = s.match(/^(-?\d+(?:\.\d+)?)(?:\s*(km\/h|kmh|kph|mph|m\/s|ms))?$/i);
            if (!m) return null;

            var num = parseFloat(m[1]);
            if (!isFinite(num)) return null;
            if (num < 0) num = 0;

            var unit = (m[2] || "").toLowerCase();

            if (unit === "mph") return num / 2.2369362920544;
            if (unit === "m/s" || unit === "ms") return num;

            if (unit === "km/h" || unit === "kmh" || unit === "kph") return num / 3.6;

            // No unit provided -> use current Units setting
            return fromDisplay(num);
          }

          function fmtTrim(n, maxDec) {
            if (!isFinite(n)) return "";
            var s = (+n).toFixed(maxDec || 0);
            // trim trailing zeros
            s = s.replace(/\.0+$/, "").replace(/(\.\d*?)0+$/, "$1");
            return s;
          }

          function refreshUnitText() {
            vm.ui.unitText = (settings.units === "mph") ? "mph" : "km/h";
          }

          function refreshSpeedLockTargetDisplay() {
            vm.ui.speedLockTargetDisplay = fmtTrim(toDisplay(settings.speedLockTargetMS || 0), 2);
          }

          function refreshInstantAccelSpeedDisplay() {
            vm.ui.instantAccelSpeedDisplay = fmtTrim(toDisplay(settings.instantAccelSpeedMS || 0), 2);
          }

          var lastSpeedMS = 0;
          var lastSpeedDisplay = 0;

          function updateSpeedText(speedMS) {
            lastSpeedMS = (typeof speedMS === "number") ? speedMS : (lastSpeedMS || 0);
            // Fix "0 ↔ 1" flicker at very low speed (near stop / after crashes).
            // We latch 0 with small hysteresis in *display units*.
            var v = toDisplay(lastSpeedMS);
            var zeroOn = 1.20;
            var zeroOff = 0.80;
            if (vm.ui.zeroLatch == null) vm.ui.zeroLatch = true;
            if (vm.ui.zeroLatch) {
              if (v >= zeroOn) vm.ui.zeroLatch = false;
              else v = 0;
            } else {
              if (v <= zeroOff) { vm.ui.zeroLatch = true; v = 0; }
            }
            lastSpeedDisplay = v;

            var dec = clamp(+settings.decimals || 0, 0, 2);
            var s = (dec === 0) ? String(Math.round(v)) : fmtFixed(v, dec);

            if (!s || s.length === 0) {
              vm.ui.speedTextMain = "";
              vm.ui.speedTextTail = "0";
              return;
            }
            if (s.length === 1) {
              vm.ui.speedTextMain = "";
              vm.ui.speedTextTail = s;
              return;
            }

            vm.ui.speedTextMain = s.slice(0, -1);
            vm.ui.speedTextTail = s.slice(-1);
          }

          var animClearT = null;
          function triggerAnim() {
            if (settings.animMode === "none") { vm.ui.animClass = ""; return; }
            var cls = (settings.animMode === "slide") ? "brsh-anim-slide" : "brsh-anim-bump";
            vm.ui.animClass = "";
            $timeout(function () { vm.ui.animClass = cls; }, 0);
            if (animClearT) $timeout.cancel(animClearT);
            animClearT = $timeout(function () { vm.ui.animClass = ""; }, clamp(settings.animDurationMs || 240, 50, 1500));
          }

          var impactT = null;
          function triggerImpactPunch() {
            vm.ui.impactPunch = false;
            $timeout(function () { vm.ui.impactPunch = true; }, 0);
            if (impactT) $timeout.cancel(impactT);
            impactT = $timeout(function () { vm.ui.impactPunch = false; }, 340);
          }

          var impactFlashT = null;
          function triggerImpactFlash() {
            if (!settings.impactFlashEnabled) return;
            vm.ui.impactFlash = false;
            $timeout(function () { vm.ui.impactFlash = true; }, 0);
            if (impactFlashT) $timeout.cancel(impactFlashT);
            impactFlashT = $timeout(function () { vm.ui.impactFlash = false; }, 380);
          }

          var failLabelPopT = null;
          function triggerFailLabelPop() {
            vm.ui.failLabelPop = false;
            $timeout(function () { vm.ui.failLabelPop = true; }, 0);
            if (failLabelPopT) $timeout.cancel(failLabelPopT);
            failLabelPopT = $timeout(function () { vm.ui.failLabelPop = false; }, 820);
          }

          var boostBannerShowT = null;
          var boostBannerHideT = null;
          var boostBannerCleanupT = null;
          function formatInstantBoostBannerText(targetSpeedMS) {
            var displayValue = Math.round(toDisplay(Math.max(0, +targetSpeedMS || 0)));
            var unit = (settings.units === "mph") ? "MPH" : "KM/H";
            return "INSTANT BOOST " + displayValue + " " + unit + " 🚀";
          }
          function showInstantBoostBanner(targetSpeedMS) {
            if (!settings.instantAccelBannerEnabled || !settings.hudVisible) return;

            vm.ui.boostBannerText = formatInstantBoostBannerText(targetSpeedMS);
            vm.ui.boostBannerVisible = true;
            vm.ui.boostBannerShow = false;

            if (boostBannerShowT) $timeout.cancel(boostBannerShowT);
            if (boostBannerHideT) $timeout.cancel(boostBannerHideT);
            if (boostBannerCleanupT) $timeout.cancel(boostBannerCleanupT);

            boostBannerShowT = $timeout(function () { vm.ui.boostBannerShow = true; }, 0);
            boostBannerHideT = $timeout(function () { vm.ui.boostBannerShow = false; }, 920);
            boostBannerCleanupT = $timeout(function () { vm.ui.boostBannerVisible = false; }, 1140);
          }

          function showDseVehiclePopup(data) {
            if (settings.dsePopupDontShowAgain) return;
            if (!settings.instantAccelEnabled) return;

            var vehicleKey = null;
            if (data && data.vehId != null) vehicleKey = String(data.vehId);
            else if (data && data.vehicleId != null) vehicleKey = String(data.vehicleId);
            else vehicleKey = "veh_" + Date.now();

            if (vm.ui.dsePopupLastVehicleKey === vehicleKey) return;
            vm.ui.dsePopupLastVehicleKey = vehicleKey;

            $timeout(function () {
              if (settings.dsePopupDontShowAgain || !settings.instantAccelEnabled) return;
              vm.ui.dsePopupVisible = true;
            }, 120, false);
          }

          function pushLogicSettingsNow() {
            var payload = {
              units: settings.units,
              sendInterval: 0.05,

              // slightly more responsive + impacts actually spike:
              gSmoothing: 0.20,
              impactSmoothing: 0.12,

              challengeEnabled: settings.challengeEnabled,
              challengeStartSpeed: +settings.challengeStartSpeed,
              challengeGraceSeconds: +settings.challengeGraceSeconds,
              challengeExplodeOnFail: settings.challengeExplodeOnFail,
              challengeLockOnFail: settings.challengeLockOnFail,

              // creator tools
              speedLockEnabled: !!settings.speedLockEnabled,
              speedLockTargetMS: +settings.speedLockTargetMS,
              speedSource: settings.speedSource,
              speedSourceBlendMs: +settings.speedSourceBlendMs,

              // instant acceleration (vehicle-side, thrusters.applyVelocity)
              instantAccelEnabled: !!settings.instantAccelEnabled,
              instantAccelMode: settings.instantAccelMode || 'set',
              instantAccelSpeedMS: +settings.instantAccelSpeedMS,
              instantAccelDuration: +settings.instantAccelDuration,
              instantAccelRamp: +settings.instantAccelRamp,
              instantAccelInvertDir: !!settings.instantAccelInvertDir
            };

            var json = JSON.stringify(payload).replace(/\]\]/g, "] ]");
            engineLua(
              "extensions.load('beamroyaleSpeedHUD');" +
              " if extensions.beamroyaleSpeedHUD and extensions.beamroyaleSpeedHUD.setSettingsJson then" +
              "   extensions.beamroyaleSpeedHUD.setSettingsJson([[" + json + "]])" +
              " end"
            );
          }

          function pushLogicSettingsDebounced() {
            if (pushLogicSettingsDebounced._t) $timeout.cancel(pushLogicSettingsDebounced._t);
            pushLogicSettingsDebounced._t = $timeout(pushLogicSettingsNow, 120);
          }

          var drag = null, resize = null, hudDrag = null, noticeDrag = null;

          function onMove(e) {
            if (drag) {
              settings.panel.x = drag.startX + (e.clientX - drag.mx);
              settings.panel.y = drag.startY + (e.clientY - drag.my);
              applyPanelStyle();
              saveDebounced();
              scope.$applyAsync();
            }
            if (resize) {
              settings.panel.w = resize.startW + (e.clientX - resize.mx);
              settings.panel.h = resize.startH + (e.clientY - resize.my);
              applyPanelStyle();
              saveDebounced();
              scope.$applyAsync();
            }
            if (hudDrag) {
              settings.hudBox.x = hudDrag.startX + (e.clientX - hudDrag.mx);
              settings.hudBox.y = hudDrag.startY + (e.clientY - hudDrag.my);

              // Auto-snap to screen center while dragging (creator-friendly positioning)
              try {
                var b = settings.hudBox;
                var w = window.innerWidth || 1920;
                var h = window.innerHeight || 1080;
                var thresh = 18;
                var cx = w * 0.5;
                var cy = h * 0.5;
                var bcx = b.x + (b.w * 0.5);
                var bcy = b.y + (b.h * 0.5);
                if (Math.abs(bcx - cx) <= thresh) b.x = Math.round(cx - b.w * 0.5);
                if (Math.abs(bcy - cy) <= thresh) b.y = Math.round(cy - b.h * 0.5);
              } catch (e) {}

              applyHudStyle();
              saveDebounced();
              scope.$applyAsync();
            }
            if (noticeDrag) {
              settings.noticeBox.x = noticeDrag.startX + (e.clientX - noticeDrag.mx);
              settings.noticeBox.y = noticeDrag.startY + (e.clientY - noticeDrag.my);
              applyNoticeStyle();
              saveDebounced();
              scope.$applyAsync();
            }
          }

          function onUp() { drag = null; resize = null; hudDrag = null; noticeDrag = null; }

          $document.on("mousemove", onMove);
          $document.on("mouseup", onUp);

          scope.$on("$destroy", function () {
            $document.off("mousemove", onMove);
            $document.off("mouseup", onUp);
            try { if (unregisterHotkey) unregisterHotkey(); } catch (e) {}

            try {
              if (typeof StreamsManager !== "undefined" && StreamsManager && typeof StreamsManager.remove === "function") {
                StreamsManager.remove(["electrics"]);
              }
            } catch (e) {}
          });

          vm.ui.dragStart = function (evt) {
            drag = { mx: evt.clientX, my: evt.clientY, startX: settings.panel.x, startY: settings.panel.y };
            evt.preventDefault(); evt.stopPropagation();
          };

          vm.ui.resizeStart = function (evt) {
            resize = { mx: evt.clientX, my: evt.clientY, startW: settings.panel.w, startH: settings.panel.h };
            evt.preventDefault(); evt.stopPropagation();
          };

          vm.ui.hudDragStart = function (evt) {
            if (!vm.ui.hudEdit) return;
            hudDrag = { mx: evt.clientX, my: evt.clientY, startX: settings.hudBox.x, startY: settings.hudBox.y };
            evt.preventDefault(); evt.stopPropagation();
          };

          vm.ui.noticeDragStart = function (evt) {
            if (!vm.ui.noticeEdit) return;
            noticeDrag = { mx: evt.clientX, my: evt.clientY, startX: settings.noticeBox.x, startY: settings.noticeBox.y };
            evt.preventDefault(); evt.stopPropagation();
          };

          function computeBaseNoticeText(ch) {
            if (!settings.noticeEnabled) return "";

            var custom = (settings.noticeCustomText || "").trim();
            if (custom) return custom;

            if (settings.challengeEnabled) {
              if (ch && ch.active) {
                return "MAINTAIN ≥ " + settings.challengeStartSpeed + " " + ((settings.units === "mph") ? "MPH" : "KM/H");
              }
              if (ch && ch.failed) {
                return "MAINTAIN ≥ " + settings.challengeStartSpeed + " " + ((settings.units === "mph") ? "MPH" : "KM/H");
              }
              return "REACH ≥ " + settings.challengeStartSpeed + " " + ((settings.units === "mph") ? "MPH" : "KM/H") + " TO START";
            }

            return "SPEED TEST";
          }

          function updateNoticeForState(ch) {
            vm.ui.noticeVisible = settings.noticeEnabled;
            vm.ui.noticeText = computeBaseNoticeText(ch);

            var showFail = !!(settings.failLabelEnabled && settings.challengeEnabled && ch && ch.failed);
            if (showFail && !vm.ui.failLabelVisible) {
              triggerFailLabelPop();
            }
            vm.ui.failLabelVisible = showFail;

            applyNoticeStyle();
          }

          function updateChallengeUI(ch) {
            vm.ui.dangerVisible = false;
            vm.ui.dangerCritical = false;
            vm.ui.dangerText = "";
            vm.ui.dangerSubText = "";
            vm.ui.fireOn = false;

            if (!settings.challengeEnabled) {
              updateNoticeForState({ active: false, failed: false });
              return;
            }

            updateNoticeForState(ch);

            if (!ch.active && !ch.failed) {
              vm.ui.fireOn = false;
              return;
            }

            if (ch.active && !ch.failed) {
              if (ch.belowT > 0) {
                var cd = Math.max(0, ch.countdown || 0);
                vm.ui.dangerVisible = true;
                vm.ui.dangerText = cd.toFixed(2) + "s";
                vm.ui.dangerSubText = "SPEED UP!";
                vm.ui.dangerCritical = (cd <= 0.75);
                vm.ui.fireOn = true;
              } else {
                vm.ui.fireOn = false;
              }
              return;
            }

            if (ch.failed) {
              vm.ui.dangerVisible = false;
              vm.ui.dangerText = "";
              vm.ui.dangerSubText = "";
              vm.ui.dangerCritical = false;
              vm.ui.fireOn = true;
            }
          }

          function applyFireStyle() {
            var s = clamp(+settings.uiFireScale || 1, 0.4, 2.2);
            var px = Math.round(220 * s);
            vm.ui.fireStyle = { width: px + "px", height: px + "px" };
          }

          function applySpeedFXFlags(speedDisplay) {
            vm.ui.streaksOn = settings.streaksEnabled && (speedDisplay >= (settings.streaksStart || 160));

            if (!settings.speedBlurEnabled) {
              vm.ui.speedTailStyle = { filter: "none", opacity: "1" };
            } else {
              var bs = settings.speedBlurStart || 220;
              var bf = settings.speedBlurFull || 360;
              var t01b = clamp((speedDisplay - bs) / (bf - bs), 0, 1);
              var blurPx = (settings.speedBlurMaxPx || 3.0) * t01b;
              vm.ui.speedTailStyle = {
                filter: (blurPx > 0.02) ? ("blur(" + blurPx.toFixed(2) + "px)") : "none",
                opacity: (1 - 0.25 * t01b).toFixed(3)
              };
            }

            if (!settings.heatEnabled) {
              vm.ui.heatOn = false;
              vm.ui.heatAuraCrit = false;
              vm.ui.heatAuraStyle = angular.extend({}, vm.ui.heatAuraStyle, { opacity: "0" });
              refreshTextStyles("");
              return;
            }

            var start = settings.heatStart || 180;
            var full = settings.heatFull || 320;
            var t01 = clamp((speedDisplay - start) / (full - start), 0, 1);

            vm.ui.heatOn = (t01 > 0.02);
            vm.ui.heatAuraCrit = (t01 >= 0.86);

            var fs = clamp(+settings.fontSize || 140, 28, 260);
            var w = clamp(Math.round(fs * (2.7 + 1.2 * t01)), 260, 820);
            var h = clamp(Math.round(fs * (1.15 + 0.55 * t01)), 170, 520);
            var blur = clamp(10 + 44 * t01, 10, 60);
            var op = clamp(0.05 + 0.62 * t01, 0, 0.75);
            var sc = 0.92 + 0.75 * t01;

            vm.ui.heatAuraStyle = {
              width: w + "px",
              height: h + "px",
              opacity: op.toFixed(3),
              filter: "blur(" + blur.toFixed(1) + "px)",
              transform: "translate(-50%,-50%) scale(" + sc.toFixed(3) + ")"
            };

            var blur1 = Math.round(22 + 92 * t01);
            var a1 = 0.06 + 0.54 * t01;
            var glow1 = "0px 0px " + blur1 + "px rgba(255,40,40," + a1.toFixed(3) + ")";

            var blur2 = Math.round(10 + 56 * t01);
            var a2 = 0.04 + 0.30 * t01;
            var glow2 = "0px 0px " + blur2 + "px rgba(255,150,0," + a2.toFixed(3) + ")";

            refreshTextStyles(glow1 + ", " + glow2);
          }

          var gIncludesGravity = null;

          function computeGEff(gMag, speedDisplay) {
            if (gIncludesGravity == null) {
              if (typeof gMag === "number") {
                if (gMag > 0.70 && gMag < 1.35 && speedDisplay < 5) gIncludesGravity = true;
                if (gMag < 0.35 && speedDisplay < 5) gIncludesGravity = false;
              }
              if (gIncludesGravity == null) gIncludesGravity = false;
            }
            var g = (typeof gMag === "number") ? gMag : 0;
            return gIncludesGravity ? Math.max(0, g - 1.0) : Math.max(0, g);
          }

          var motion = {
            gSm: 0,
            impSm: 0,

            sx: 0, sy: 0, rot: 0,
            tx: 0, ty: 0, trot: 0,
            nextT: 0,

            kx: 0, ky: 0, krot: 0,

            prevImp: 0,
            lastImpactTrigMs: 0
          };

          function addImpactKick(impVal) {
            if (!settings.impactPunchEnabled) return;
            var th = (settings.impactThreshold || 1.2);
            var i01 = clamp((impVal - th) / 3.0, 0, 1);
            if (i01 <= 0) return;

            var amp = 6 + 22 * i01;
            motion.kx += (Math.random() * 2 - 1) * amp;
            motion.ky += (Math.random() * 2 - 1) * amp;
            motion.krot += (Math.random() * 2 - 1) * (1.2 + 5.4 * i01);
          }

          function stepMotion(dt, gMagRaw, impactRaw, speedDisplay, isLua) {
            dt = clamp(dt || 0.05, 0.01, 0.2);

            var gEff = computeGEff(gMagRaw, speedDisplay);
            var imp = Math.max(0, (typeof impactRaw === "number") ? impactRaw : 0);

            // Less smoothing when Lua already pre-smooths:
            var gTau = isLua ? 0.10 : 0.22;
            var gA = (gTau <= 0) ? 1 : clamp(dt / (gTau + dt), 0, 1);
            motion.gSm = motion.gSm * (1 - gA) + gEff * gA;

            var iTau = isLua ? 0.06 : 0.18;
            var iA = (iTau <= 0) ? 1 : clamp(dt / (iTau + dt), 0, 1);
            motion.impSm = motion.impSm * (1 - iA) + imp * iA;

            var sx = 0, sy = 0, rot = 0;

            if (settings.gShakeEnabled) {
              var gate = (settings.gShakeStartSpeed || 0);
              if (speedDisplay >= gate) {
                // more responsive mapping, still deadzoned
                var dead = 0.18;
                var range = 1.9;
                var g01 = clamp((motion.gSm - dead) / range, 0, 1);
                g01 = Math.pow(g01, 1.35);

                var ampPx = (settings.gShakePx || 0) * g01;

                if (ampPx >= 0.25) {
                  motion.nextT -= dt;
                  if (motion.nextT <= 0) {
                    var minP = 0.05;
                    var maxP = 0.14;
                    motion.nextT = clamp(maxP - (maxP - minP) * g01, minP, maxP);

                    motion.tx = (Math.random() * 2 - 1) * ampPx;
                    motion.ty = (Math.random() * 2 - 1) * ampPx;
                    motion.trot = (Math.random() * 2 - 1) * (ampPx * 0.14);
                  }

                  var lerp = clamp(dt / (0.085 + dt), 0, 1);
                  motion.sx = motion.sx + (motion.tx - motion.sx) * lerp;
                  motion.sy = motion.sy + (motion.ty - motion.sy) * lerp;
                  motion.rot = motion.rot + (motion.trot - motion.rot) * lerp;
                } else {
                  var lerp0 = clamp(dt / (0.08 + dt), 0, 1);
                  motion.sx = motion.sx + (0 - motion.sx) * lerp0;
                  motion.sy = motion.sy + (0 - motion.sy) * lerp0;
                  motion.rot = motion.rot + (0 - motion.rot) * lerp0;
                  motion.tx = 0; motion.ty = 0; motion.trot = 0; motion.nextT = 0;
                }
              } else {
                var lerpS = clamp(dt / (0.08 + dt), 0, 1);
                motion.sx = motion.sx + (0 - motion.sx) * lerpS;
                motion.sy = motion.sy + (0 - motion.sy) * lerpS;
                motion.rot = motion.rot + (0 - motion.rot) * lerpS;
                motion.tx = 0; motion.ty = 0; motion.trot = 0; motion.nextT = 0;
              }
            } else {
              var lerpD = clamp(dt / (0.08 + dt), 0, 1);
              motion.sx = motion.sx + (0 - motion.sx) * lerpD;
              motion.sy = motion.sy + (0 - motion.sy) * lerpD;
              motion.rot = motion.rot + (0 - motion.rot) * lerpD;
              motion.tx = 0; motion.ty = 0; motion.trot = 0; motion.nextT = 0;
            }

            sx += motion.sx; sy += motion.sy; rot += motion.rot;

            var decay = Math.exp(-dt / 0.14);
            motion.kx *= decay;
            motion.ky *= decay;
            motion.krot *= decay;

            sx += motion.kx; sy += motion.ky; rot += motion.krot;

            return { x: sx, y: sy, r: rot, impSm: motion.impSm };
          }

          var localCh = { active: false, failed: false, belowT: 0, countdown: 0 };

          function resetLocalChallengeIfNeeded(soft) {
            localCh.active = false;
            localCh.failed = false;
            localCh.belowT = 0;
            localCh.countdown = (settings.challengeGraceSeconds || 2.0);
            if (!soft) vm.ui.failLabelVisible = false;
          }

          function stepLocalChallenge(dt, speedDisplay) {
            if (!settings.challengeEnabled) {
              resetLocalChallengeIfNeeded(true);
              return { active: false, failed: false, belowT: 0, countdown: 0 };
            }

            if (localCh.failed) {
              return { active: false, failed: true, belowT: localCh.belowT, countdown: 0 };
            }

            if (!localCh.active) {
              if (speedDisplay >= (settings.challengeStartSpeed || 100)) {
                localCh.active = true;
                localCh.belowT = 0;
                localCh.countdown = (settings.challengeGraceSeconds || 2.0);
              }
              return { active: localCh.active, failed: false, belowT: 0, countdown: (settings.challengeGraceSeconds || 2.0) };
            }

            var startSpeed = (settings.challengeStartSpeed || 100);
            var grace = (settings.challengeGraceSeconds || 2.0);

            if (speedDisplay < startSpeed) {
              localCh.belowT += Math.max(0, dt || 0);
              localCh.countdown = Math.max(0, grace - localCh.belowT);
              if (localCh.belowT >= grace) {
                localCh.failed = true;
                localCh.active = false;

                if (settings.challengeExplodeOnFail || settings.challengeLockOnFail) {
                  engineLua(
                    "extensions.load('beamroyaleSpeedHUD');" +
                    " if extensions.beamroyaleSpeedHUD and extensions.beamroyaleSpeedHUD.forceFail then" +
                    "   extensions.beamroyaleSpeedHUD.forceFail()" +
                    " end"
                  );
                }
              }
              return { active: localCh.active, failed: localCh.failed, belowT: localCh.belowT, countdown: localCh.countdown };
            }

            localCh.belowT = 0;
            localCh.countdown = grace;
            return { active: true, failed: false, belowT: 0, countdown: grace };
          }

          var lastRenderedKey = "";
          var lastLuaUpdateMs = 0;

          // ----- speed reference / blending (wheel vs air vs dynamic)
          var teleWheelMS = 0;
          var teleAirMS = 0;
          var speedBlend = 0; // 0 = wheel, 1 = air

          function dynWantsAir(wheelMS, airMS) {
            wheelMS = Math.max(0, +wheelMS || 0);
            airMS = Math.max(0, +airMS || 0);
            if (airMS < 5) return false; // don't switch at very low speeds

            var diff = Math.abs(wheelMS - airMS);

            // wheel speed near zero but air speed is high => likely airborne
            if (wheelMS < 0.6 && airMS >= 5) return true;

            // large mismatch => prefer air
            if (diff >= 2.0) {
              var rel = diff / Math.max(airMS, 0.001);
              if (rel >= 0.22) return true;
            }

            // wheels spinning wildly faster than travel speed
            if (wheelMS > airMS * 1.35 && airMS >= 5) return true;

            return false;
          }

          function computeSpeedBlendTarget() {
            var m = settings.speedSource;
            if (m === "air") return 1;
            if (m === "wheel") return 0;
            // dynamic
            return dynWantsAir(teleWheelMS, teleAirMS) ? 1 : 0;
          }

          function getEffectiveSpeedMS(dtSeconds) {
            var dt = Math.max(0.001, +dtSeconds || 0.05);
            var blendMs = clamp(+settings.speedSourceBlendMs || 400, 60, 1500);
            var t = blendMs / 1000;
            var target = computeSpeedBlendTarget();

            var a = clamp(dt / Math.max(0.05, t), 0, 1);
            speedBlend = speedBlend + (target - speedBlend) * a;

            var w = Math.max(0, +teleWheelMS || 0);
            var air = Math.max(0, +teleAirMS || 0);
            if (w > 0 && air > 0) return w * (1 - speedBlend) + air * speedBlend;
            return (settings.speedSource === "wheel") ? (w || air) : (air || w);
          }

          function handleTelemetry(data, source, dtSeconds, opts) {
            if (!data) return;
            if (source === "lua") lastLuaUpdateMs = Date.now();
            var dt = (dtSeconds || 0.05);

            // update cached speeds (streams provide both; lua provides at least one)
            if (typeof data.wheelSpeedMS === "number") teleWheelMS = data.wheelSpeedMS;
            if (typeof data.airSpeedMS === "number") teleAirMS = data.airSpeedMS;
            if (typeof data.speedMS === "number" && typeof data.airSpeedMS !== "number") {
              // treat legacy field as airspeed
              teleAirMS = data.speedMS;
            }

            // always compute display speed from selected reference
            var effectiveSpeedMS = getEffectiveSpeedMS(dt);
            updateSpeedText(effectiveSpeedMS);

              var key = vm.ui.speedTextMain + vm.ui.speedTextTail + "|" + settings.decimals;
              if (key !== lastRenderedKey) {
                triggerAnim();
                lastRenderedKey = key;
              }

              applySpeedFXFlags(lastSpeedDisplay);

            if (opts && opts.speedOnly) return;

            var gRaw =
              (typeof data.gMag === "number") ? data.gMag :
              ((typeof data.g === "number") ? data.g : 0);

            var impRaw = (typeof data.impact === "number") ? data.impact : 0;

            var m = stepMotion(dt, gRaw, impRaw, lastSpeedDisplay, source === "lua");
            vm.ui.hudStyle = angular.extend({}, vm.ui.hudStyle, {
              transform: "translate(" + m.x.toFixed(2) + "px," + m.y.toFixed(2) + "px) rotate(" + m.r.toFixed(2) + "deg)"
            });

            // ✅ FIX: impacts trigger if Punch OR Flash is enabled
            // ✅ FIX: cooldown trigger so it doesn't miss spikes
            var impactEnabled = (settings.impactPunchEnabled || settings.impactFlashEnabled);
            if (impactEnabled) {
              var th = (settings.impactThreshold || 1.2);
              var nowMs = Date.now();

              // use raw for Lua (already smoothed/meaningful), smoothed for streams
              var impTrig = (source === "lua") ? impRaw : m.impSm;

              if (impTrig >= th && (nowMs - (motion.lastImpactTrigMs || 0) > 220)) {
                if (settings.impactPunchEnabled) triggerImpactPunch();
                triggerImpactFlash();
                addImpactKick(impTrig);
                motion.lastImpactTrigMs = nowMs;
              }

              motion.prevImp = impTrig;
            }

            var ch;
            if (source === "lua" && (data.challengeEnabled !== undefined || data.challengeActive !== undefined)) {
              ch = {
                enabled: (data.challengeEnabled === true),
                active: (data.challengeActive === true),
                failed: (data.challengeFailed === true),
                belowT: (typeof data.challengeBelowT === "number") ? data.challengeBelowT : 0,
                countdown: (typeof data.challengeCountdown === "number") ? data.challengeCountdown : 0
              };
            } else {
              ch = stepLocalChallenge(dtSeconds || 0, lastSpeedDisplay);
              ch.enabled = settings.challengeEnabled;
            }

            updateChallengeUI(ch);

            if (!handleTelemetry._lastFailed && ch.failed) {
              vm.ui.failFlash = true;
              if (vm.ui.failFlashT) $timeout.cancel(vm.ui.failFlashT);
              vm.ui.failFlashT = $timeout(function () { vm.ui.failFlash = false; }, 1200);
            }
            handleTelemetry._lastFailed = !!ch.failed;

            applyFireStyle();
            refreshUnitText();
          }

          scope.$on("BeamRoyalSpeedHUDUpdate", function (_evt, data) {
            handleTelemetry(data, "lua", 0.05);
          });

          scope.$on("BeamRoyalSpeedHUDInstantBoost", function (_evt, data) {
            var targetMS = 0;
            if (data && typeof data.targetSpeedMS === "number") targetMS = data.targetSpeedMS;
            else if (data && typeof data.speedMS === "number") targetMS = data.speedMS;
            showInstantBoostBanner(targetMS);
          });

          scope.$on("BeamRoyalSpeedHUDDSEPopup", function (_evt, data) {
            showDseVehiclePopup(data || {});
          });

          var streamPrevT = 0;
          var streamPrevSpeed = 0;
          var streamPrevAcc = 0;

          function ensureStreams() {
            try {
              if (typeof StreamsManager !== "undefined" && StreamsManager && typeof StreamsManager.add === "function") {
                StreamsManager.add(["electrics"]);
                return true;
              }
            } catch (e) {}
            return false;
          }

          ensureStreams();

          scope.$on("streamsUpdate", function (_evt, streams) {
            if (!streams || !streams.electrics) return;

            var wheel = streams.electrics.wheelspeed;
            if (typeof wheel !== "number") wheel = streams.electrics.wheelSpeed;

            var air = streams.electrics.airspeed;
            if (typeof air !== "number") air = streams.electrics.airSpeed;

            var speedForAcc = (typeof wheel === "number") ? wheel : ((typeof air === "number") ? air : 0);

            var now = Date.now() * 0.001;
            var dt = 0.05;
            if (streamPrevT > 0) dt = clamp(now - streamPrevT, 0.01, 0.2);
            streamPrevT = now;

            var speedMS = speedForAcc;
            var acc = (speedMS - streamPrevSpeed) / dt;
            var jerk = (acc - streamPrevAcc) / dt;

            streamPrevSpeed = speedMS;
            streamPrevAcc = acc;

            var gMag = Math.abs(acc) / 9.81;
            var impact = Math.abs(jerk) / 9.81;

            // If Lua is active, use streams only for speed (wheel/air) so we don't override
            // challenge state coming from the logic extension.
            if (Date.now() - lastLuaUpdateMs < 250) {
              handleTelemetry({ wheelSpeedMS: wheel, airSpeedMS: air, speedMS: speedMS }, "streams", dt, { speedOnly: true });
              return;
            }

            handleTelemetry({ wheelSpeedMS: wheel, airSpeedMS: air, speedMS: speedMS, gMag: gMag, impact: impact }, "streams", dt);
          });

          scope.$watch(
            function () {
              return (
                settings.units + "|" +
                settings.decimals + "|" +
                settings.showUnit + "|" +
                settings.speedSource + "|" +
                settings.speedSourceBlendMs + "|" +
                settings.speedLockEnabled + "|" +
                settings.speedLockTargetMS + "|" +
                settings.instantAccelEnabled + "|" +
                settings.instantAccelMode + "|" +
                settings.instantAccelSpeedMS + "|" +
                settings.instantAccelDuration + "|" +
                settings.instantAccelRamp + "|" +
                settings.instantAccelInvertDir + "|" +
                settings.instantAccelBannerEnabled + "|" +
                settings.fontSize + "|" +
                settings.textOpacity + "|" +
                settings.hudColor + "|" +
                settings.unitScale + "|" +
                settings.shadowEnabled + "|" +
                settings.shadowBlur + "|" +
                settings.shadowX + "|" +
                settings.shadowY + "|" +
                settings.shadowOpacity + "|" +
                settings.outlineEnabled + "|" +
                settings.outlineSize + "|" +
                settings.outlineOpacity + "|" +
                settings.outlineColor + "|" +
                settings.animMode + "|" +
                settings.animDurationMs + "|" +
                settings.hudVisible + "|" +
                settings.gShakeEnabled + "|" +
                settings.gShakePx + "|" +
                settings.gShakeStartSpeed + "|" +
                settings.impactPunchEnabled + "|" +
                settings.impactThreshold + "|" +
                settings.impactFlashEnabled + "|" +
                settings.impactFlashStrength + "|" +
                settings.streaksEnabled + "|" +
                settings.streaksStart + "|" +
                settings.heatEnabled + "|" +
                settings.heatStart + "|" +
                settings.heatFull + "|" +
                settings.speedBlurEnabled + "|" +
                settings.speedBlurStart + "|" +
                settings.speedBlurFull + "|" +
                settings.speedBlurMaxPx + "|" +
                settings.challengeEnabled + "|" +
                settings.challengeStartSpeed + "|" +
                settings.challengeGraceSeconds + "|" +
                settings.challengeExplodeOnFail + "|" +
                settings.challengeLockOnFail + "|" +
                settings.uiFireScale + "|" +
                settings.dangerFontSize + "|" +
                settings.noticeEnabled + "|" +
                settings.noticeCustomText + "|" +
                settings.noticeFontSize + "|" +
                settings.noticeShowIcon + "|" +
                settings.failLabelEnabled + "|" +
                settings.failLabelFontSize + "|" +
                settings.failLabelColor + "|" +
                settings.failLabelShadowEnabled + "|" +
                settings.failLabelShadowBlur + "|" +
                settings.failLabelShadowX + "|" +
                settings.failLabelShadowY + "|" +
                settings.failLabelShadowOpacity + "|" +
                settings.failLabelOutlineEnabled + "|" +
                settings.failLabelOutlineSize + "|" +
                settings.failLabelOutlineOpacity + "|" +
                settings.failLabelOutlineColor + "|" +
                settings.showSettingsButton
              );
            },
            function () {
              normalize();
              applyHudStyle();
              applyNoticeStyle();
              refreshTextStyles(lastGlowShadow);
              refreshUnitText();
              refreshSpeedLockTargetDisplay();
              refreshInstantAccelSpeedDisplay();
              updateSpeedText(lastSpeedMS);
              applySpeedFXFlags(lastSpeedDisplay);
              refreshFailLabelStyles();
              applyFireStyle();
              pushLogicSettingsDebounced();
              saveDebounced();
            }
          );

          applyPanelStyle();
          applyHudStyle();
          applyNoticeStyle();
          refreshUnitText();
          refreshSpeedLockTargetDisplay();
          refreshInstantAccelSpeedDisplay();
          updateSpeedText(0);
          applySpeedFXFlags(0);
          refreshFailLabelStyles();
          applyFireStyle();

          $timeout(function () {
            engineLua("extensions.load('beamroyaleSpeedHUD')");
            pushLogicSettingsNow();
          }, 50);

          window.addEventListener("resize", function () {
            normalize();
            applyHudStyle();
            applyNoticeStyle();
            applyPanelStyle();
            scope.$applyAsync();
          });
        }
      };
    }
  ]);
})();
