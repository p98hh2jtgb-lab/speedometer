local M = {}

-- Settings are overwritten by UI via setSettingsJson()
local settings = {
  units = "kmh",                -- "kmh" | "mph"
  sendInterval = 0.05,

  -- smoothing in seconds (bigger = smoother)
  gSmoothing = 0.25,
  impactSmoothing = 0.35,

  -- Speed Maintenance Challenge
  challengeEnabled = false,
  challengeStartSpeed = 100,    -- in DISPLAY units (km/h or mph depending on settings.units)
  challengeGraceSeconds = 2.0,
  challengeExplodeOnFail = true,
  challengeLockOnFail = true
}

-- vehicle tracking
local vehId = -1
local vehObj = nil

-- last settings payload received from UI; forwarded to vehicle-side creator extension
local lastSettingsJson = nil

-- one-shot vehicle prep for Instant Boost cars
local boostPrep = {
  lastInstantAccelEnabled = false,
  preparedVehicleIds = {},
  warnedVehicleIds = {},
  popupSuppressUntil = 0,
  preparing = false
}

-- timing / throttle
local sendAcc = 0
local lastSentSpeed = -999
local lastSentG = -999
local lastSentImpact = -999
local lastSentChActive = nil
local lastSentChFailed = nil
local lastSentChBelowT = nil

-- motion history (for fallbacks + accel/impact)
local prevPos = nil
local prevVel = nil
local prevAcc = nil

-- smoothed values
local gSm = 0
local impactSm = 0

-- challenge state
local challenge = {
  active = false,     -- becomes true only AFTER you reach start speed
  failed = false,
  belowT = 0,
  countdown = 0
}

-- ---------------- utils ----------------

local function clamp(v, mn, mx)
  if v < mn then return mn end
  if v > mx then return mx end
  return v
end

local function safeJsonDecode(s)
  if type(s) ~= "string" then return nil end
  local ok, res = pcall(function() return jsonDecode(s) end)
  if ok then return res end
  return nil
end

local function copyPos(v)
  if not v then return nil end
  return { x = v.x or 0, y = v.y or 0, z = v.z or 0 }
end

local function dist2D(a, b)
  if not a or not b then return 0 end
  local dx = (a.x or 0) - (b.x or 0)
  local dy = (a.y or 0) - (b.y or 0)
  return math.sqrt(dx*dx + dy*dy)
end

local function vecLen(v)
  if not v then return 0 end
  local x = v.x or 0
  local y = v.y or 0
  local z = v.z or 0
  return math.sqrt(x*x + y*y + z*z)
end

local function getPlayerVehicle()
  local id = be:getPlayerVehicleID(0)
  if not id or id == -1 then return nil, -1 end
  local o = be:getObjectByID(id)
  if not o then return nil, -1 end
  return o, id
end

local function ensureCreatorVehicleExt(o)
  if not o or not lastSettingsJson then return end

  -- Guard against Lua long-bracket terminator inside payload
  local payload = lastSettingsJson:gsub('%]%]', '] ]')

  local cmd = "extensions.load('beamroyaleSpeedHUDCreator');" ..
              " if extensions.beamroyaleSpeedHUDCreator and extensions.beamroyaleSpeedHUDCreator.setSettingsJson then" ..
              " extensions.beamroyaleSpeedHUDCreator.setSettingsJson([[" .. payload .. "]]) end"
  pcall(function() o:queueLuaCommand(cmd) end)
end

local function getVehPos(o)
  if not o or type(o.getPosition) ~= "function" then return nil end
  local ok, pos = pcall(function() return o:getPosition() end)
  if ok then return pos end
  return nil
end

-- Try a bunch of velocity access patterns.
-- Returns {x,y,z} or nil.
local function getVehVel(o)
  if not o then return nil end

  local function tryCall(name)
    local fn = o[name]
    if type(fn) ~= "function" then return nil end
    local ok, a, b, c = pcall(fn, o)
    if not ok then return nil end

    -- Case 1: returns vec3 / table
    if type(a) == "table" or type(a) == "userdata" then
      local vx = (a.x ~= nil) and a.x or 0
      local vy = (a.y ~= nil) and a.y or 0
      local vz = (a.z ~= nil) and a.z or 0
      return { x = vx, y = vy, z = vz }
    end

    -- Case 2: returns x,y,z
    if type(a) == "number" and type(b) == "number" then
      return { x = a, y = b, z = (type(c) == "number") and c or 0 }
    end

    return nil
  end

  local names = {
    "getVelocity",
    "getVelocityXYZ",
    "getLinearVelocity",
    "getLinearVelocityXYZ"
  }

  for _, n in ipairs(names) do
    local v = tryCall(n)
    if v then return v end
  end

  return nil
end

local function toDisplay(speedMS)
  if settings.units == "mph" then
    return speedMS * 2.2369362920544
  end
  return speedMS * 3.6
end

local function getCurrentSpeedMS(o)
  return vecLen(getVehVel(o))
end

local function normalizeSearchText(s)
  if type(s) ~= "string" then return "" end
  s = s:lower()
  s = s:gsub('&', ' and ')
  s = s:gsub('[_%-%./]+', ' ')
  s = s:gsub('%s+', ' ')
  return s
end

local function textHasWord(s, word)
  if s == "" or word == "" then return false end
  if s == word then return true end
  if s:find(word .. ' ', 1, true) == 1 then return true end
  if s:find(' ' .. word, 1, true) then return true end
  return false
end

local function looksLikeDSEText(s)
  local n = normalizeSearchText(s)
  if n == "" then return false end
  if n:find('driving and safety electronics', 1, true) then return true end
  if n:find('driving safety electronics', 1, true) then return true end
  if n:find('driver safety electronics', 1, true) then return true end
  return false
end

local dseSlotHints = {
  'driving_safety_electronics',
  'driving_and_safety_electronics',
  'drivingSafetyElectronics',
  'drivingAndSafetyElectronics',
  'driver_safety_electronics',
  'driverSafetyElectronics',
  'safety_electronics',
  'safetyElectronics',
  'vehicle_electronics',
  'vehicleElectronics',
  'dse'
}

local function looksLikeDSEKey(slotName)
  if type(slotName) ~= "string" then return false end

  for _, hint in ipairs(dseSlotHints) do
    if slotName == hint then return true end
  end

  local n = normalizeSearchText(slotName)
  if n == "" then return false end
  if looksLikeDSEText(n) then return true end

  local hasDriving = textHasWord(n, 'driving') or textHasWord(n, 'driver')
  local hasSafety = textHasWord(n, 'safety')
  local hasElectronics = textHasWord(n, 'electronics') or textHasWord(n, 'electronic')
  if hasDriving and hasSafety and hasElectronics then return true end

  if n == 'dse' or n:find(' dse ', 1, true) or n:find(' dse$', 1) then return true end

  return false
end

local function tableContainsDSEText(value, depth, seen)
  depth = depth or 0
  if depth > 5 then return false end

  local t = type(value)
  if t == 'string' then
    return looksLikeDSEText(value)
  end

  if t ~= 'table' then return false end

  seen = seen or {}
  if seen[value] then return false end
  seen[value] = true

  for k, v in pairs(value) do
    if type(k) == 'string' and looksLikeDSEText(k) then
      return true
    end
    if tableContainsDSEText(v, depth + 1, seen) then
      return true
    end
  end

  return false
end

local function findInstantBoostDSESlot(configParts)
  if type(configParts) ~= 'table' then return nil end

  for slotName, _ in pairs(configParts) do
    if looksLikeDSEKey(slotName) then
      return slotName
    end
  end

  local ok, slotMap = pcall(function()
    extensions.load('core_vehicle_manager')
    local mgr = extensions and extensions.core_vehicle_manager
    if not mgr or type(mgr.getPlayerVehicleData) ~= 'function' then return nil end
    local vehData = mgr.getPlayerVehicleData()
    if not vehData or not vehData.ioCtx then return nil end
    return require('jbeam/io').getAvailableSlotMap(vehData.ioCtx)
  end)

  if ok and type(slotMap) == 'table' then
    for slotName, slotData in pairs(slotMap) do
      if configParts[slotName] ~= nil then
        if looksLikeDSEKey(slotName) or tableContainsDSEText(slotData, 0, {}) then
          return slotName
        end
      end
    end
  end

  for slotName, partName in pairs(configParts) do
    if looksLikeDSEKey(slotName) or looksLikeDSEText(partName) then
      return slotName
    end
  end

  return nil
end

local function tryAutoDisableDSEForInstantBoost()
  if settings.instantAccelEnabled ~= true then return false end

  local o, id = getPlayerVehicle()
  if not o or not id or id == -1 then return false end
  if boostPrep.preparing or boostPrep.preparedVehicleIds[id] then return false end

  local okLoad = pcall(function()
    extensions.load('core_vehicle_partmgmt')
  end)
  if not okLoad then return false end

  local partmgmt = extensions and extensions.core_vehicle_partmgmt
  if not partmgmt or type(partmgmt.getConfig) ~= 'function' or type(partmgmt.setPartsConfig) ~= 'function' then
    return false
  end

  local okCfg, cfg = pcall(function() return partmgmt.getConfig() end)
  if not okCfg or type(cfg) ~= 'table' or type(cfg.parts) ~= 'table' then
    return false
  end

  local slotName = findInstantBoostDSESlot(cfg.parts)
  if not slotName then
    return false
  end

  if cfg.parts[slotName] == '' then
    boostPrep.preparedVehicleIds[id] = true
    return true
  end

  boostPrep.preparing = true
  cfg.parts[slotName] = ''

  local applied = false
  local okApply = pcall(function()
    partmgmt.setPartsConfig(cfg.parts, true)
    applied = true
  end)

  boostPrep.preparing = false

  if okApply and applied then
    boostPrep.preparedVehicleIds[id] = true
    boostPrep.popupSuppressUntil = (os.clock() or 0) + 1.5
    return true
  end

  return false
end

local function maybePrepareInstantBoostVehicle()
  if settings.instantAccelEnabled == true then
    tryAutoDisableDSEForInstantBoost()
  end
end

local function maybeTriggerInstantBoostDSEPopupForVehicle(id)
  if settings.instantAccelEnabled ~= true then return end

  local vid = tonumber(id) or tonumber(vehId) or -1
  if vid == -1 then return end
  if boostPrep.warnedVehicleIds[vid] then return end

  boostPrep.warnedVehicleIds[vid] = true
  guihooks.trigger('BeamRoyalSpeedHUDDSEPopup', { vehId = vid })
end

-- ---------------- UI messaging ----------------

local function sendToUI(speedMS, speedDisplay, gMag, impact, force)
  local chActive = challenge.active
  local chFailed = challenge.failed
  local chBelowT = challenge.belowT

  if not force then
    if math.abs((speedMS or 0) - (lastSentSpeed or 0)) < 0.02
      and math.abs((gMag or 0) - (lastSentG or 0)) < 0.03
      and math.abs((impact or 0) - (lastSentImpact or 0)) < 0.03
      and chActive == lastSentChActive
      and chFailed == lastSentChFailed
      and math.abs((chBelowT or 0) - (lastSentChBelowT or 0)) < 0.03 then
      return
    end
  end

  lastSentSpeed = speedMS or 0
  lastSentG = gMag or 0
  lastSentImpact = impact or 0
  lastSentChActive = chActive
  lastSentChFailed = chFailed
  lastSentChBelowT = chBelowT

  guihooks.trigger("BeamRoyalSpeedHUDUpdate", {
    speedMS = speedMS or 0,
    speedDisplay = speedDisplay or 0,
    unit = settings.units,

    gMag = gMag or 0,
    impact = impact or 0,

    challengeEnabled = settings.challengeEnabled == true,
    challengeActive = challenge.active == true,
    challengeFailed = challenge.failed == true,
    challengeBelowT = challenge.belowT or 0,
    challengeCountdown = challenge.countdown or 0
  })
end

-- ---------------- challenge helpers ----------------

local function clearChallengeState()
  challenge.active = false
  challenge.failed = false
  challenge.belowT = 0
  challenge.countdown = 0
end

function M.resetChallenge()
  clearChallengeState()

  local o = vehObj
  if o and o.queueLuaCommand then
    pcall(function() o:queueLuaCommand("controller.setFreeze(false)") end)
    pcall(function() o:queueLuaCommand("electrics.setIgnitionLevel(2)") end)
    pcall(function() o:queueLuaCommand("fire.setActive(false)") end)
  end

  sendToUI(0, 0, gSm, impactSm, true)
end

-- NEW: UI fallback may call this; also useful for external scripts
function M.forceFail()
  if not (settings.challengeEnabled == true) then return end
  if challenge.failed == true then return end

  challenge.failed = true
  challenge.active = false
  challenge.belowT = (challenge.belowT or 0)
  challenge.countdown = 0

  local o = vehObj
  if not o then
    o = select(1, getPlayerVehicle())
  end

  if o and o.queueLuaCommand then
    if settings.challengeExplodeOnFail then
      pcall(function() o:queueLuaCommand("fire.setActive(true)") end)
      pcall(function() o:queueLuaCommand("beamstate.breakAllBreakgroups()") end)
    end
    if settings.challengeLockOnFail then
      pcall(function() o:queueLuaCommand("controller.setFreeze(true)") end)
      pcall(function() o:queueLuaCommand("electrics.setIgnitionLevel(0)") end)
    end
  end

  sendToUI(0, 0, gSm, impactSm, true)
end

function M.toggleSettings()
  guihooks.trigger("BeamRoyalSpeedHUDToggleSettings")
end

-- Hotkey action: Instant Boost (vehicle-side helper)
function M.triggerInstantAcceleration()
  -- If the UI did not enable it, do nothing.
  if settings and settings.instantAccelEnabled == false then return end
  local o = vehObj or select(1, getPlayerVehicle())
  if not o or not o.queueLuaCommand then return end

  local target = clamp(tonumber(settings.instantAccelSpeedMS) or 0, 0, 2000)
  if settings.instantAccelMode == 'add' then
    target = clamp(getCurrentSpeedMS(o) + target, 0, 2000)
  end

  guihooks.trigger("BeamRoyalSpeedHUDInstantBoost", { targetSpeedMS = target })

  ensureCreatorVehicleExt(o)
  pcall(function()
    o:queueLuaCommand("extensions.load('beamroyaleSpeedHUDCreator'); if extensions.beamroyaleSpeedHUDCreator and extensions.beamroyaleSpeedHUDCreator.triggerInstantAcceleration then extensions.beamroyaleSpeedHUDCreator.triggerInstantAcceleration() end")
  end)
end

-- ---------------- public API ----------------

function M.setSettingsJson(jsonStr)
  local tset = safeJsonDecode(jsonStr)
  if type(tset) ~= "table" then return end

  local wasInstantAccelEnabled = boostPrep.lastInstantAccelEnabled == true

  -- Store raw payload (forwarded to vehicle-side creator tools)
  if type(jsonStr) == "string" then
    lastSettingsJson = jsonStr
  end
  for k, v in pairs(tset) do
    settings[k] = v
  end

  if settings.units ~= "mph" then settings.units = "kmh" end
  settings.sendInterval = clamp(tonumber(settings.sendInterval) or 0.05, 0.01, 0.25)
  settings.gSmoothing = clamp(tonumber(settings.gSmoothing) or 0.25, 0.0, 2.0)
  settings.impactSmoothing = clamp(tonumber(settings.impactSmoothing) or 0.35, 0.0, 2.0)

  settings.challengeStartSpeed = clamp(tonumber(settings.challengeStartSpeed) or 100, 1, 2000)
  settings.challengeGraceSeconds = clamp(tonumber(settings.challengeGraceSeconds) or 2.0, 0.05, 20.0)

  boostPrep.lastInstantAccelEnabled = settings.instantAccelEnabled == true

  -- Ensure vehicle-side creator extension is loaded and receives the same settings
  local o = vehObj or select(1, getPlayerVehicle())
  ensureCreatorVehicleExt(o)

  if boostPrep.lastInstantAccelEnabled and not wasInstantAccelEnabled then
    maybePrepareInstantBoostVehicle()
  end
end

function M.onExtensionLoaded()
  vehObj, vehId = getPlayerVehicle()
  boostPrep.preparedVehicleIds = {}
  boostPrep.warnedVehicleIds = {}
  boostPrep.popupSuppressUntil = 0
  boostPrep.preparing = false
  ensureCreatorVehicleExt(vehObj)
  prevPos = nil
  prevVel = nil
  prevAcc = nil
  gSm = 0
  impactSm = 0
  sendAcc = 0
  clearChallengeState()
  maybePrepareInstantBoostVehicle()
  maybeTriggerInstantBoostDSEPopupForVehicle(vehId)
  sendToUI(0, 0, 0, 0, true)
end

function M.onVehicleResetted(id)
  if type(id) == "number" and id == vehId then
    boostPrep.preparedVehicleIds[id] = nil
    ensureCreatorVehicleExt(vehObj)
    prevPos = nil
    prevVel = nil
    prevAcc = nil
    gSm = 0
    impactSm = 0
    sendAcc = 0
    clearChallengeState()
    maybePrepareInstantBoostVehicle()
    sendToUI(0, 0, 0, 0, true)
  end
end
M.onVehicleReset = M.onVehicleResetted

-- ---------------- main update ----------------

function M.onUpdate(dt)
  dt = dt or 0
  if dt <= 0 then return end

  local o, id = getPlayerVehicle()
  if not o then return end

  if id ~= vehId then
    local suppressPopupForThisVehicle = (tonumber(boostPrep.popupSuppressUntil) or 0) > (os.clock() or 0)
    if suppressPopupForThisVehicle then
      boostPrep.popupSuppressUntil = 0
    end

    vehId = id
    vehObj = o
    ensureCreatorVehicleExt(vehObj)
    prevPos = nil
    prevVel = nil
    prevAcc = nil
    gSm = 0
    impactSm = 0
    sendAcc = 0
    clearChallengeState()
    maybePrepareInstantBoostVehicle()
    if not suppressPopupForThisVehicle then
      maybeTriggerInstantBoostDSEPopupForVehicle(id)
    end
    sendToUI(0, 0, 0, 0, true)
  end

  local pos = getVehPos(o)
  if not pos then return end

  -- detect teleport / big snap
  local teleported = false
  if prevPos then
    local jump = dist2D(prevPos, pos)
    if jump > 100 then
      teleported = true
      prevPos = copyPos(pos)
      prevVel = nil
      prevAcc = nil
      gSm = 0
      impactSm = 0
      -- do NOT clear if already failed (prevents weird re-arming)
      if not challenge.failed then
        clearChallengeState()
      end
    end
  end

  local vel = getVehVel(o)
  if not vel then
    if prevPos and not teleported and dt > 0 then
      vel = {
        x = (pos.x - prevPos.x) / dt,
        y = (pos.y - prevPos.y) / dt,
        z = (pos.z - prevPos.z) / dt
      }
    else
      vel = { x = 0, y = 0, z = 0 }
    end
  end

  local speedMS = vecLen(vel)
  local speedDisplay = toDisplay(speedMS)

  local acc = { x = 0, y = 0, z = 0 }
  if prevVel and not teleported and dt > 0 then
    acc = {
      x = (vel.x - prevVel.x) / dt,
      y = (vel.y - prevVel.y) / dt,
      z = (vel.z - prevVel.z) / dt
    }
  end

  local jerkMag = 0
  if prevAcc and not teleported and dt > 0 then
    local j = {
      x = (acc.x - prevAcc.x) / dt,
      y = (acc.y - prevAcc.y) / dt,
      z = (acc.z - prevAcc.z) / dt
    }
    jerkMag = vecLen(j)
  end

  local gMag = vecLen(acc) / 9.80665
  local impact = jerkMag / 9.80665

  do
    local s = tonumber(settings.gSmoothing) or 0.25
    local alpha = (s <= 0) and 1 or clamp(dt / (s + dt), 0, 1)
    gSm = gSm * (1 - alpha) + gMag * alpha
  end

  do
    local s = tonumber(settings.impactSmoothing) or 0.35
    local alpha = (s <= 0) and 1 or clamp(dt / (s + dt), 0, 1)
    impactSm = impactSm * (1 - alpha) + impact * alpha
  end

  -- update challenge
  if settings.challengeEnabled == true then
    if teleported and not challenge.failed then
      clearChallengeState()
    end

    if not challenge.failed then
      local startSpeed = tonumber(settings.challengeStartSpeed) or 100
      local grace = tonumber(settings.challengeGraceSeconds) or 2.0

      if not challenge.active then
        if speedDisplay >= startSpeed then
          challenge.active = true
          challenge.belowT = 0
          challenge.countdown = grace
        end
      else
        if speedDisplay < startSpeed then
          challenge.belowT = (challenge.belowT or 0) + dt
          challenge.countdown = math.max(0, grace - challenge.belowT)

          if challenge.belowT >= grace then
            challenge.failed = true
            challenge.active = false
            challenge.countdown = 0

            if o and o.queueLuaCommand then
              if settings.challengeExplodeOnFail then
                pcall(function() o:queueLuaCommand("fire.setActive(true)") end)
                pcall(function() o:queueLuaCommand("beamstate.breakAllBreakgroups()") end)
              end
              if settings.challengeLockOnFail then
                pcall(function() o:queueLuaCommand("controller.setFreeze(true)") end)
                pcall(function() o:queueLuaCommand("electrics.setIgnitionLevel(0)") end)
              end
            end
          end
        else
          challenge.belowT = 0
          challenge.countdown = grace
        end
      end
    end
  else
    clearChallengeState()
  end

  prevPos = copyPos(pos)
  prevVel = { x = vel.x or 0, y = vel.y or 0, z = vel.z or 0 }
  prevAcc = { x = acc.x or 0, y = acc.y or 0, z = acc.z or 0 }

  sendAcc = sendAcc + dt
  local interval = tonumber(settings.sendInterval) or 0.05
  if sendAcc >= interval then
    sendAcc = 0
    sendToUI(speedMS, speedDisplay, gSm, impactSm, false)
  end
end

return M
