-- BeamRoyal Speed HUD Mod - Creator tools (speed lock + speed reference selection)
--
-- Features implemented here:
--   * Target Speed Lock: once the vehicle reaches the user-defined target speed,
--     it will try to maintain that speed until the vehicle is reset (or feature disabled).
--   * Speed reference modes: wheelspeed / airspeed / dynamic blend.
--     Dynamic mode blends wheel & air speeds smoothly, so switching doesn't "jump".
--
-- Notes:
--   * Exact speed locking is limited by physics + drivetrain; this uses a PID-like
--     throttle/brake controller to keep speed very close to the target.
--   * Designed to be safe: when disabled it releases throttle/brake back to the player.

local M = {}

-- -------------------------------------------------------------
-- helpers

local abs, min, max = math.abs, math.min, math.max

local function clamp(v, a, b)
  if v == nil then return a end
  if v < a then return a end
  if v > b then return b end
  return v
end

local function safeJsonDecode(s)
  if type(s) ~= 'string' then return nil end
  local ok, res
  if type(jsonDecode) == 'function' then
    ok, res = pcall(jsonDecode, s)
  elseif json and type(json.decode) == 'function' then
    ok, res = pcall(json.decode, s)
  end
  if ok and type(res) == 'table' then return res end
  return nil
end

local function getWheelSpeedMS()
  local ev = electrics and electrics.values
  local ws = ev and ev.wheelspeed
  if type(ws) == 'number' then return abs(ws) end
  return 0
end

local function getAirSpeedMS()
  local ev = electrics and electrics.values
  local as = ev and (ev.airspeed or ev.airSpeed or ev.air_speed)
  if type(as) == 'number' then return abs(as) end

  -- fallback (rare): magnitude of velocity vector
  if obj and obj.getVelocity then
    local v = obj:getVelocity()
    if v and v.x then
      return math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
    end
  end
  return 0
end

-- BeamNG input "Filter" types (Key/Pad/Direct). Setting all three ensures the
-- limiter works regardless of the user's control device / binding filter.
local FILTER_KBD = (type(FILTER_KBD) == 'number') and FILTER_KBD or 0
local FILTER_PAD = (type(FILTER_PAD) == 'number') and FILTER_PAD or 1
local FILTER_DIRECT = (type(FILTER_DIRECT) == 'number') and FILTER_DIRECT or 2
local FILTERS = { FILTER_KBD, FILTER_PAD, FILTER_DIRECT }

local function setPedals(throttle, brake)
  throttle = clamp(throttle or 0, 0, 1)
  brake = clamp(brake or 0, 0, 1)

  if input and type(input.event) == 'function' then
    for _, f in ipairs(FILTERS) do
      input.event('throttle', throttle, f)
      input.event('brake', brake, f)
    end
    return
  end

  -- last-resort fallback
  if electrics and electrics.values then
    electrics.values.throttle_input = throttle
    electrics.values.brake_input = brake
  end
end

-- -------------------------------------------------------------
-- settings + state

local cfg = {
  speedLockEnabled = false,
  speedLockTargetMS = 0,
  speedSource = 'wheel', -- 'wheel' | 'air' | 'dynamic'
  speedSourceBlendMs = 400,

  -- Instant Acceleration
  -- IMPORTANT: We intentionally do NOT use torque multipliers or node forces here.
  -- Those approaches can break engines/drivetrains and cause instability pauses.
  --
  -- Instead we use BeamNG's built-in Vehicle Lua helper:
  --   thrusters.applyVelocity(vec3VelocityMS)
  -- which (per official patch notes) can speed up a vehicle to a certain speed.
  --
  -- 'set' : speed up to target speed (m/s)
  -- 'add' : add the value (m/s) to current speed and speed up to that
  instantAccelEnabled = false,
  instantAccelMode = 'set',
  instantAccelSpeedMS = 27.7777777778, -- 100 km/h default
  instantAccelDuration = 0.20,         -- seconds to keep applying the target (0 = one-shot)
  instantAccelRamp = 0.00,             -- seconds to ramp up (0 = instant)
  instantAccelInvertDir = false,       -- if your game build reports direction reversed, flip it here

  -- dynamic heuristics
  dynMinAirMS = 5.0,          -- don't switch to air at very low speed
  dynDiffMS = 2.0,            -- min absolute difference before considering switch
  dynRelDiff = 0.22,          -- or relative difference threshold
  dynWheelLowMS = 0.6,        -- wheel speed near-zero but air is high => likely airborne

  -- engage/hold tuning
  engageTolMS = 0.06,         -- engage when within this tolerance (m/s)
  holdDeadbandMS = 0.02,      -- deadband around target
  pidKp = 0.22,
  pidKi = 0.10,
  pidKd = 0.015,
  pidIMax = 6.0,
  pidOutMax = 1.0
}

local st = {
  armed = false,
  engaged = false,
  armPrevErr = nil,
  integral = 0,
  prevErr = 0,
  blend = 0, -- 0 = wheel, 1 = air
  lastEnable = false,

  -- Instant Acceleration runtime state
  boostActive = false,
  boostT = 0,
  boostHold = 0,
  boostRamp = 0,
  boostStartSpeedMS = 0,
  boostTargetSpeedMS = 0,
  boostReleaseT = 0
}

-- -------------------------------------------------------------
-- Instant Acceleration helpers

local function ensureThrusters()
  if thrusters and type(thrusters.applyVelocity) == 'function' then return true end
  if extensions and type(extensions.load) == 'function' then
    pcall(function() extensions.load('thrusters') end)
  end
  return thrusters and type(thrusters.applyVelocity) == 'function'
end

local function getSpeedMS()
  -- Prefer physics velocity magnitude; fallback to wheelspeed.
  if obj and obj.getVelocity then
    local ok, v = pcall(function() return obj:getVelocity() end)
    if ok and v then
      local vv = vec3(v)
      local s = vv:length()
      if type(s) == 'number' and s == s then return s end
    end
  end
  return getWheelSpeedMS()
end

local function getForwardVec3()
  local f = vec3(0, 1, 0)
  if obj and obj.getDirectionVector then
    local ok, v = pcall(function() return obj:getDirectionVector() end)
    if ok and v then
      f = vec3(v)
    end
  end
  local len = f:length()
  if len < 1e-6 then return vec3(0, 1, 0) end
  f = f / len
  if cfg.instantAccelInvertDir then
    f = -f
  end
  return f
end

local function getBoostDirVec3()
  if obj and obj.getVelocity then
    local ok, v = pcall(function() return obj:getVelocity() end)
    if ok and v then
      local vv = vec3(v)
      local len = vv:length()
      if len > 1.0 then
        vv = vv / len
        if cfg.instantAccelInvertDir then
          vv = -vv
        end
        return vv
      end
    end
  end

  return getForwardVec3()
end

local function stopBoost(releaseT)
  st.boostActive = false
  st.boostT = 0
  st.boostHold = 0
  st.boostRamp = 0
  st.boostStartSpeedMS = 0
  st.boostTargetSpeedMS = 0
  st.boostReleaseT = max(st.boostReleaseT or 0, clamp(releaseT or 0, 0, 2.0))
  setPedals(0, 0)
end

local function updateBoostRelease(dt)
  local t = tonumber(st.boostReleaseT) or 0
  if t <= 0 then return end
  st.boostReleaseT = max(0, t - (dt or 0))
  setPedals(0, 0)
end

local function startBoostToSpeed(targetSpeedMS)
  if not ensureThrusters() then
    log('W', 'beamroyaleSpeedHUDCreator', 'Instant Acceleration requires thrusters.applyVelocity (BeamNG v0.25+)')
    return
  end

  st.boostActive = true
  st.boostT = 0
  st.boostHold = clamp(tonumber(cfg.instantAccelDuration) or 0, 0, 20.0)
  st.boostRamp = clamp(tonumber(cfg.instantAccelRamp) or 0, 0, 5.0)
  st.boostStartSpeedMS = getSpeedMS()
  st.boostTargetSpeedMS = max(0, targetSpeedMS or 0)
  st.boostReleaseT = 0
  setPedals(0, 0)
end

local function updateBoost(dt)
  if not st.boostActive then return false end
  if not cfg.instantAccelEnabled then
    stopBoost(0.35)
    return false
  end
  if not ensureThrusters() then
    stopBoost(0.35)
    return false
  end

  st.boostT = (st.boostT or 0) + (dt or 0)
  local t = st.boostT

  local ramp = st.boostRamp or 0
  local hold = st.boostHold or 0
  local total = ramp + hold

  -- If both are zero, we still want exactly one application.
  local shouldStopAfterThisTick = (total <= 0) and (t > 0)

  local speed = st.boostTargetSpeedMS or 0
  if ramp > 0 and t < ramp then
    local a = clamp(t / ramp, 0, 1)
    speed = (st.boostStartSpeedMS or 0) + ((st.boostTargetSpeedMS or 0) - (st.boostStartSpeedMS or 0)) * a
  end

  -- Keep player inputs released while boosting so stale throttle/brake state does not
  -- fight the helper or feel like the car is locking up.
  setPedals(0, 0)

  local currentSpeed = getSpeedMS()
  local tol = 0.35
  if speed > 0.05 and (currentSpeed + tol) < speed then
    local dir = getBoostDirVec3()
    -- applyVelocity expects a world velocity vector in m/s.
    pcall(function() thrusters.applyVelocity(dir * speed) end)
  end

  if shouldStopAfterThisTick or (total > 0 and t >= total) then
    stopBoost(0.35)
    return false
  end

  return true
end

local function resetControllerState()
  -- Always stop boost on reset/reload.
  stopBoost(0)
  st.boostReleaseT = 0
  st.armed = cfg.speedLockEnabled == true
  st.engaged = false
  st.armPrevErr = nil
  st.integral = 0
  st.prevErr = 0
  -- keep blend (nice when switching sources)
  setPedals(0, 0)
end

-- -------------------------------------------------------------
-- speed source blending

local function dynamicWantsAir(wheelMS, airMS)
  wheelMS = wheelMS or 0
  airMS = airMS or 0
  if airMS < (cfg.dynMinAirMS or 0) then return false end

  local diff = abs(wheelMS - airMS)
  if wheelMS < (cfg.dynWheelLowMS or 0) and airMS >= (cfg.dynMinAirMS or 0) then
    return true
  end

  if diff >= (cfg.dynDiffMS or 0) then
    local rel = diff / max(airMS, 0.001)
    if rel >= (cfg.dynRelDiff or 0.2) then
      return true
    end
  end

  -- wheels spinning much faster than vehicle speed
  if airMS >= (cfg.dynMinAirMS or 0) and wheelMS > airMS * 1.35 then
    return true
  end

  return false
end

local function computeBlendTarget(wheelMS, airMS)
  local m = cfg.speedSource
  if m == 'air' then return 1 end
  if m == 'wheel' then return 0 end
  -- dynamic
  return dynamicWantsAir(wheelMS, airMS) and 1 or 0
end

local function updateBlend(dt, target)
  local t = clamp((cfg.speedSourceBlendMs or 400) / 1000, 0.05, 2.0)
  local a = clamp(dt / t, 0, 1)
  st.blend = st.blend + (target - st.blend) * a
end

local function getEffectiveSpeedMS(dt)
  local w = getWheelSpeedMS()
  local a = getAirSpeedMS()

  local bt = computeBlendTarget(w, a)
  updateBlend(dt, bt)

  local eff
  if w > 0 and a > 0 then
    eff = w * (1 - st.blend) + a * st.blend
  else
    -- if one is unavailable, just use the other
    eff = (a > 0) and a or w
  end

  -- return effective speed + the raw sources for callers that need them
  return eff, w, a
end

-- -------------------------------------------------------------
-- speed lock control loop

local function updateSpeedLock(dt)
  -- During boost (and the short release window after it) we suspend the speed lock
  -- controller so it does not fight the boost or make the car feel brake-locked.
  if st.boostActive or (st.boostReleaseT or 0) > 0 then return end
  if not cfg.speedLockEnabled or (cfg.speedLockTargetMS or 0) <= 0 then
    if st.engaged or st.armed or st.lastEnable then
      st.lastEnable = false
      resetControllerState()
    end
    return
  end

  -- detect toggles (so turning it on re-arms)
  if not st.lastEnable then
    st.lastEnable = true
    st.armed = true
    st.engaged = false
    st.integral = 0
    st.prevErr = 0
    st.armPrevErr = nil
    setPedals(0, 0)
  end

  local speed, wheelMS = getEffectiveSpeedMS(dt)
  local target = cfg.speedLockTargetMS
  -- For actual control, prefer wheelspeed (more stable on-ground reference).
  local controlSpeed = (type(wheelMS) == 'number' and wheelMS > 0) and wheelMS or speed
  local err = target - controlSpeed

  if not st.engaged then
    -- Engage only when we "reach" the target.
    --
    -- To make this usable in practice (where speed may step over the exact target),
    -- we also engage when crossing the target from below/above.
    local prevErr = st.armPrevErr
    st.armPrevErr = err

    local tol = (cfg.engageTolMS or 0.06)
    local crossed = (type(prevErr) == "number") and ((prevErr > 0 and err <= 0) or (prevErr < 0 and err >= 0))

    if st.armed and (abs(err) <= tol or crossed) then
      st.engaged = true
      st.integral = 0
      st.prevErr = err
      st.armPrevErr = nil
    else
      return
    end
  end

  -- PID-like control
  local dead = cfg.holdDeadbandMS or 0
  if abs(err) < dead then
    err = 0
  end

  st.integral = clamp(st.integral + err * dt, -(cfg.pidIMax or 6), (cfg.pidIMax or 6))
  local deriv = (err - (st.prevErr or 0)) / max(dt, 0.001)
  st.prevErr = err

  local u = (cfg.pidKp or 0.22) * err + (cfg.pidKi or 0.10) * st.integral + (cfg.pidKd or 0.015) * deriv
  u = clamp(u, -(cfg.pidOutMax or 1), (cfg.pidOutMax or 1))

  local throttle, brake
  if u >= 0 then
    throttle = u
    brake = 0
  else
    throttle = 0
    brake = -u
  end

  setPedals(throttle, brake)
end

-- -------------------------------------------------------------
-- public API

function M.triggerInstantAcceleration()
  if not cfg.instantAccelEnabled then return end

  local value = max(0, tonumber(cfg.instantAccelSpeedMS) or 0)
  local mode = cfg.instantAccelMode

  local target = value
  if mode == 'add' then
    target = getSpeedMS() + value
  end

  -- Safety clamp (helps avoid physics instability pauses from absurd values)
  target = clamp(target, 0, 2000) -- 2000 m/s ~= 7200 km/h

  startBoostToSpeed(target)
end

function M.setSettingsJson(jsonStr)
  local data = safeJsonDecode(jsonStr)
  if not data then return end

  if type(data.speedLockEnabled) == 'boolean' then cfg.speedLockEnabled = data.speedLockEnabled end
  if type(data.speedLockTargetMS) == 'number' then cfg.speedLockTargetMS = max(0, data.speedLockTargetMS) end

  if type(data.speedSource) == 'string' then
    local s = data.speedSource
    if s == 'wheel' or s == 'air' or s == 'dynamic' then cfg.speedSource = s end
  end
  if type(data.speedSourceBlendMs) == 'number' then cfg.speedSourceBlendMs = clamp(data.speedSourceBlendMs, 60, 1500) end

  -- Instant Acceleration
  if type(data.instantAccelEnabled) == 'boolean' then cfg.instantAccelEnabled = data.instantAccelEnabled end
  if type(data.instantAccelMode) == 'string' then
    local m = data.instantAccelMode
    if m == 'set' or m == 'add' then cfg.instantAccelMode = m end
  end
  if type(data.instantAccelSpeedMS) == 'number' then cfg.instantAccelSpeedMS = clamp(data.instantAccelSpeedMS, 0, 5000) end
  if type(data.instantAccelDuration) == 'number' then cfg.instantAccelDuration = clamp(data.instantAccelDuration, 0, 20.0) end
  if type(data.instantAccelRamp) == 'number' then cfg.instantAccelRamp = clamp(data.instantAccelRamp, 0, 5.0) end
  if type(data.instantAccelInvertDir) == 'boolean' then cfg.instantAccelInvertDir = data.instantAccelInvertDir end

  -- If toggled off, make sure controls release immediately.
  if not cfg.speedLockEnabled then
    st.lastEnable = false
    resetControllerState()
  end

  -- If boost was disabled mid-run, release immediately.
  if not cfg.instantAccelEnabled then
    stopBoost(0.35)
  end
end

function M.onReset()
  resetControllerState()
end

function M.onExtensionLoaded()
  resetControllerState()
end

-- Apply control in both physics and gfx steps so it reliably overrides
-- player input regardless of update order.
local function step(dt)
  dt = dt or 0
  updateBoost(dt)
  updateBoostRelease(dt)
  updateSpeedLock(dt)
end

function M.update(dt)
  step(dt)
end

function M.updateGFX(dt)
  step(dt)
end


-- Some BeamNG versions/extensions also call onUpdate/onUpdateGFX.
-- Implement them as aliases for maximum compatibility.
function M.onUpdate(dt)
  step(dt)
end

function M.onUpdateGFX(dt)
  step(dt)
end

return M
