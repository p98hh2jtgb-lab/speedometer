-- BeamRoyal Speed HUD (Vehicle extension)
-- Sends UI updates:
--   guihooks.trigger('BeamRoyalSpeedHUDUpdate', {...})
-- and run finalized:
--   guihooks.trigger('BeamRoyalSpeedHUDRunFinished', {...})
--
-- Computes:
--  - Top speed (m/s)
--  - 0-100 / 0-200 / 0-300 km/h times
--  - 100-200 / 200-300 km/h segment times
--  - 60 ft, 1/8, 1/4, 1/2, 1 mile times (distance traveled)
-- Supports:
--  - Speedtrap start/end spheres (from GE settings), or free mode (start speed threshold)

local M = {}

local settings = {
  trapEnabled = false,
  trapShowMarkers = true,
  trapRadius = 8,
  trapStartPos = nil,
  trapEndPos = nil,

  runStartSpeedMS = 2.2222,
  runEndSpeedMS = 0.8333,
  runEndConfirmMs = 900
}

local enabled = false

local t = 0

local sendAcc = 0
local sendInterval = 0.05

local prevPos = nil
local prevVel = nil

local gSmooth = 1.0

-- free-mode start hysteresis
local prevSpeedMS = 0

-- trap edge detection
local wasInStart = false
local wasInEnd = false

local run = {
  active = false,
  mode = "free",
  startT = 0,
  elapsed = 0,
  distM = 0,
  maxSpeedMS = 0,

  t0_100 = -1,
  t0_200 = -1,
  t0_300 = -1,

  t100_200 = -1,
  t200_300 = -1,

  t60ft = -1,
  t1_8 = -1,
  t1_4 = -1,
  t1_2 = -1,
  t1_mile = -1,

  cross100 = -1,
  cross200 = -1,
  cross300 = -1
}

local endSlowAcc = 0
local runPrevPos = nil

-- ---------- helpers ----------

local function safeJsonDecode(s)
  if type(s) ~= "string" then return nil end
  local ok, res = pcall(function() return jsonDecode(s) end)
  if ok then return res end
  return nil
end

local function safeVecTable(v)
  if type(v) ~= "table" then return nil end
  local x = tonumber(v.x)
  local y = tonumber(v.y)
  local z = tonumber(v.z)
  if x == nil or y == nil or z == nil then return nil end
  return { x = x, y = y, z = z }
end

local function copyPos(v)
  if not v then return nil end
  return { x = v.x or 0, y = v.y or 0, z = v.z or 0 }
end

local function dist2D(a, b)
  local dx = (a.x or 0) - (b.x or 0)
  local dy = (a.y or 0) - (b.y or 0)
  return math.sqrt(dx*dx + dy*dy)
end

local function dist3D(a, b)
  local dx = (a.x or 0) - (b.x or 0)
  local dy = (a.y or 0) - (b.y or 0)
  local dz = (a.z or 0) - (b.z or 0)
  return math.sqrt(dx*dx + dy*dy + dz*dz)
end

local function getPos()
  if obj and type(obj.getPosition) == "function" then
    local ok, p = pcall(function() return obj:getPosition() end)
    if ok then return p end
  end
  return nil
end

local function getVel()
  if obj and type(obj.getVelocity) == "function" then
    local ok, v = pcall(function() return obj:getVelocity() end)
    if ok then return v end
  end
  return nil
end

local function getWheelSpeed()
  if electrics and electrics.values and type(electrics.values.wheelspeed) == "number" then
    return electrics.values.wheelspeed
  end
  return 0
end

local function getGear()
  if electrics and electrics.values then
    if type(electrics.values.gear) == "number" then return electrics.values.gear end
    if type(electrics.values.gearIndex) == "number" then return electrics.values.gearIndex end
  end
  return 0
end

local function clamp(v, mn, mx)
  if v < mn then return mn end
  if v > mx then return mx end
  return v
end

local function toLua(v)
  local tv = type(v)
  if tv == "number" then
    if v ~= v then return "0" end
    if v == math.huge or v == -math.huge then return "0" end
    return string.format("%.6f", v)
  end
  if tv == "boolean" then return v and "true" or "false" end
  if tv == "string" then return string.format("%q", v) end
  if tv == "nil" then return "nil" end
  if tv == "table" then
    local parts = {}
    for k, val in pairs(v) do
      local kk
      if type(k) == "string" and k:match("^[%a_][%w_]*$") then
        kk = k
      else
        kk = "[" .. toLua(k) .. "]"
      end
      parts[#parts+1] = kk .. "=" .. toLua(val)
    end
    return "{" .. table.concat(parts, ",") .. "}"
  end
  return "nil"
end

local function sendUI(eventName, payload)
  if not obj or type(obj.queueGameEngineLua) ~= "function" then return end
  local cmd = "guihooks.trigger(" .. string.format("%q", eventName) .. ", " .. toLua(payload) .. ")"
  pcall(function() obj:queueGameEngineLua(cmd) end)
end

-- ---------- run logic ----------

local SPEED_100 = 27.7777777778
local SPEED_200 = 55.5555555556
local SPEED_300 = 83.3333333333

local FT = 0.3048
local D_60FT = 60 * FT
local MILE = 1609.344
local D_1_8 = MILE / 8
local D_1_4 = MILE / 4
local D_1_2 = MILE / 2
local D_1_MILE = MILE

local function resetRun()
  run.active = false
  run.mode = "free"
  run.startT = t
  run.elapsed = 0
  run.distM = 0
  run.maxSpeedMS = 0

  run.t0_100 = -1
  run.t0_200 = -1
  run.t0_300 = -1

  run.t100_200 = -1
  run.t200_300 = -1

  run.t60ft = -1
  run.t1_8 = -1
  run.t1_4 = -1
  run.t1_2 = -1
  run.t1_mile = -1

  run.cross100 = -1
  run.cross200 = -1
  run.cross300 = -1

  endSlowAcc = 0
  runPrevPos = nil
end

local function startRun(mode, posNow)
  resetRun()
  run.active = true
  run.mode = mode or "free"
  run.startT = t
  run.elapsed = 0
  run.distM = 0
  run.maxSpeedMS = 0
  endSlowAcc = 0
  runPrevPos = copyPos(posNow)
end

local function updateMilestones(speedMS)
  local e = run.elapsed

  if run.t0_100 < 0 and speedMS >= SPEED_100 then
    run.t0_100 = e
    run.cross100 = e
  end

  if run.t0_200 < 0 and speedMS >= SPEED_200 then
    run.t0_200 = e
    run.cross200 = e
    if run.cross100 > 0 and run.t100_200 < 0 then
      run.t100_200 = run.cross200 - run.cross100
    end
  end

  if run.t0_300 < 0 and speedMS >= SPEED_300 then
    run.t0_300 = e
    run.cross300 = e
    if run.cross200 > 0 and run.t200_300 < 0 then
      run.t200_300 = run.cross300 - run.cross200
    end
  end
end

local function updateDistanceMilestones()
  local e = run.elapsed
  local d = run.distM

  if run.t60ft < 0 and d >= D_60FT then run.t60ft = e end
  if run.t1_8 < 0 and d >= D_1_8 then run.t1_8 = e end
  if run.t1_4 < 0 and d >= D_1_4 then run.t1_4 = e end
  if run.t1_2 < 0 and d >= D_1_2 then run.t1_2 = e end
  if run.t1_mile < 0 and d >= D_1_MILE then run.t1_mile = e end
end

local function finishRun()
  local payload = {
    mode = run.mode,
    topSpeedMS = run.maxSpeedMS,

    t0_100 = run.t0_100,
    t0_200 = run.t0_200,
    t0_300 = run.t0_300,

    t100_200 = run.t100_200,
    t200_300 = run.t200_300,

    t60ft = run.t60ft,
    t1_8 = run.t1_8,
    t1_4 = run.t1_4,
    t1_2 = run.t1_2,
    t1_mile = run.t1_mile
  }

  sendUI("BeamRoyalSpeedHUDRunFinished", payload)

  -- clear run state after sending result
  resetRun()
end

-- ---------- g-force (best-effort) ----------

local G0 = 9.80665

local function computeG(dt)
  -- Prefer sensors if present (proper acceleration)
  if sensors then
    local gx = tonumber(sensors.gx)
    local gy = tonumber(sensors.gy)
    local gz = tonumber(sensors.gz)
    if gx and gy and gz then
      local mag = math.sqrt(gx*gx + gy*gy + gz*gz)
      return mag
    end
  end

  -- Fallback: derive acceleration from velocity and subtract gravity
  local vel = getVel()
  if not vel or dt <= 0 then return gSmooth end

  if not prevVel then
    prevVel = { x = vel.x, y = vel.y, z = vel.z }
    return gSmooth
  end

  local ax = (vel.x - prevVel.x) / dt
  local ay = (vel.y - prevVel.y) / dt
  local az = (vel.z - prevVel.z) / dt

  prevVel.x = vel.x
  prevVel.y = vel.y
  prevVel.z = vel.z

  -- remove gravity (gravity is roughly -G0 in Z)
  local px = ax
  local py = ay
  local pz = az + G0

  local mag = math.sqrt(px*px + py*py + pz*pz) / G0
  return mag
end

-- ---------- public API ----------

function M.enable()
  enabled = true
end

function M.setSettingsJson(jsonStr)
  local tset = safeJsonDecode(jsonStr)
  if type(tset) ~= "table" then return end

  if type(tset.trapEnabled) == "boolean" then settings.trapEnabled = tset.trapEnabled end
  if type(tset.trapShowMarkers) == "boolean" then settings.trapShowMarkers = tset.trapShowMarkers end
  if type(tset.trapRadius) == "number" then settings.trapRadius = clamp(tset.trapRadius, 1, 30) end

  settings.trapStartPos = safeVecTable(tset.trapStartPos)
  settings.trapEndPos = safeVecTable(tset.trapEndPos)

  if type(tset.runStartSpeedMS) == "number" then settings.runStartSpeedMS = math.max(0, tset.runStartSpeedMS) end
  if type(tset.runEndSpeedMS) == "number" then settings.runEndSpeedMS = math.max(0, tset.runEndSpeedMS) end
  if type(tset.runEndConfirmMs) == "number" then settings.runEndConfirmMs = clamp(tset.runEndConfirmMs, 0, 5000) end
end

function M.onReset()
  t = 0
  sendAcc = 0
  prevPos = nil
  prevVel = nil
  prevSpeedMS = 0
  wasInStart = false
  wasInEnd = false
  gSmooth = 1.0
  resetRun()
end

-- ---------- main update ----------

local function update(dt)
  if not enabled then return end
  dt = dt or 0
  if dt <= 0 then return end

  t = t + dt
  sendAcc = sendAcc + dt

  local pos = getPos()
  if not pos then return end

  local speedMS = getWheelSpeed()
  local gear = getGear()

  -- G-force smoothing
  local gNow = computeG(dt)
  local alpha = 0.18
  gSmooth = gSmooth * (1 - alpha) + gNow * alpha

  -- Trap sphere checks (edge-triggered)
  local startSet = (settings.trapStartPos ~= nil)
  local endSet = (settings.trapEndPos ~= nil)
  local rad = settings.trapRadius or 8

  local inStart = false
  local inEnd = false

  if startSet then
    inStart = (dist3D(settings.trapStartPos, pos) <= rad)
  end
  if endSet then
    inEnd = (dist3D(settings.trapEndPos, pos) <= rad)
  end

  -- Start logic
  if settings.trapEnabled and startSet and endSet then
    -- Trap mode start: entering START sphere when not running
    if not run.active and inStart and not wasInStart then
      startRun("trap", pos)
    end
  else
    -- Free mode start: cross start speed threshold upward
    if not run.active then
      local s0 = settings.runStartSpeedMS or 0
      local crossedUp = (prevSpeedMS < s0) and (speedMS >= s0) and (speedMS > 0.05)
      if crossedUp then
        startRun("free", pos)
      end
    end
  end

  -- Run active updates
  if run.active then
    run.elapsed = t - run.startT
    run.maxSpeedMS = math.max(run.maxSpeedMS, speedMS)

    -- distance traveled (2D)
    if runPrevPos then
      run.distM = run.distM + dist2D(runPrevPos, pos)
    end
    runPrevPos = copyPos(pos)

    updateMilestones(speedMS)
    updateDistanceMilestones()

    -- End logic
    if run.mode == "trap" then
      -- finish on entering END sphere
      if inEnd and not wasInEnd then
        finishRun()
      end
    else
      -- free mode: finish after staying below end speed for confirm time
      local endS = settings.runEndSpeedMS or 0
      local confirm = (settings.runEndConfirmMs or 0) / 1000.0

      if speedMS <= endS then
        endSlowAcc = endSlowAcc + dt
        if confirm <= 0 or endSlowAcc >= confirm then
          finishRun()
        end
      else
        endSlowAcc = 0
      end
    end
  end

  -- Send UI update on interval
  if sendAcc >= sendInterval then
    sendAcc = 0

    sendUI("BeamRoyalSpeedHUDUpdate", {
      speedMS = speedMS,
      gear = gear,
      g = gSmooth,

      runActive = run.active,
      runMode = run.mode,
      runElapsed = run.elapsed,
      runDistM = run.distM,
      runMaxSpeedMS = run.maxSpeedMS,

      t0_100 = run.t0_100,
      t0_200 = run.t0_200,
      t0_300 = run.t0_300,
      t100_200 = run.t100_200,
      t200_300 = run.t200_300,

      t60ft = run.t60ft,
      t1_8 = run.t1_8,
      t1_4 = run.t1_4,
      t1_2 = run.t1_2,
      t1_mile = run.t1_mile
    })
  end

  wasInStart = inStart
  wasInEnd = inEnd
  prevSpeedMS = speedMS
  prevPos = pos
end

function M.updateGFX(dt) update(dt) end
function M.onUpdate(dt) update(dt) end

return M
