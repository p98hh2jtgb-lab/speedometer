angular.module('beamng.apps')
.directive('creatorpackPanel', ['$rootScope', function($rootScope) {
  return {
    replace: true,
    restrict: 'EA',
    templateUrl: '/ui/modules/apps/CreatorPack/app.html',
    link: function(scope, element) {
      function load(key, fallback) {
        try { return JSON.parse(localStorage.getItem(key)) || fallback }
        catch(e) { return fallback }
      }

      scope.hudOn = false
      scope.collapsed = load('cp_collapsed', false)
      scope.cost = 0
      scope.bumping = false

      var panelPos = load('cp_pos_panel', {x: 20, y: 20})
      var damagePos = load('cp_pos_damage', {x: 20, y: 100})
      var damageW = parseInt(localStorage.getItem('cp_w_damage') || '160', 10)
      var damageH = parseInt(localStorage.getItem('cp_h_damage') || '50', 10)

      scope.survivalOn = false
      scope.survival = 100
      scope.survivalBumping = false
      scope.survivalColor = '#ffffff'
      scope.sensitivity = load('cp_sensitivity', 5)

      var survivalPos = load('cp_pos_survival', {x: 20, y: 160})
      var survivalW = parseInt(localStorage.getItem('cp_w_survival') || '160', 10)
      var survivalH = parseInt(localStorage.getItem('cp_h_survival') || '50', 10)
      var survivalBumpDelay = null
      var survivalBumpTimer = null

      var panel = element[0].querySelector('.cp-panel')
      var hud = element[0].querySelector('.cp-hud')

      if (!panel || !hud) return

      panel.style.left = panelPos.x + 'px'
      panel.style.top = panelPos.y + 'px'
      hud.style.left = damagePos.x + 'px'
      hud.style.top = damagePos.y + 'px'
      hud.style.width = damageW + 'px'
      hud.style.height = damageH + 'px'

      var survivalHud = element[0].querySelectorAll('.cp-hud')[1]

      if (survivalHud) {
        survivalHud.style.left = survivalPos.x + 'px'
        survivalHud.style.top = survivalPos.y + 'px'
        survivalHud.style.width = survivalW + 'px'
        survivalHud.style.height = survivalH + 'px'
      }

      function makeDraggable(el, handle, storageKey) {
        handle.addEventListener('mousedown', function(e) {
          if (e.target.closest('.cp-hud-grip') || e.target.closest('.cp-collapse-btn') || e.target.closest('.cp-toggle')) return
          e.preventDefault()
          var startX = e.clientX
          var startY = e.clientY
          var startL = parseInt(el.style.left, 10) || 0
          var startT = parseInt(el.style.top, 10) || 0

          function onMove(e) {
            var x = Math.max(0, Math.min(window.innerWidth - el.offsetWidth, startL + e.clientX - startX))
            var y = Math.max(0, Math.min(window.innerHeight - el.offsetHeight, startT + e.clientY - startY))
            el.style.left = x + 'px'
            el.style.top = y + 'px'
          }

          function onUp() {
            localStorage.setItem(storageKey, JSON.stringify({
              x: parseInt(el.style.left, 10),
              y: parseInt(el.style.top, 10)
            }))
            document.removeEventListener('mousemove', onMove)
            document.removeEventListener('mouseup', onUp)
          }

          document.addEventListener('mousemove', onMove)
          document.addEventListener('mouseup', onUp)
        })
      }

      function updateHudScale(el, h) {
        h = h || el.offsetHeight
        var label = el.querySelector('.cph-label')
        var value = el.querySelector('.cph-value')
        if (label) label.style.fontSize = Math.max(8, Math.round(h * 0.20)) + 'px'
        if (value) value.style.fontSize = Math.max(14, Math.round(h * 0.44)) + 'px'
      }

      function makeResizable(el, grip, wKey, hKey, onResize) {
        grip.addEventListener('mousedown', function(e) {
          e.preventDefault()
          e.stopPropagation()
          var startX = e.clientX
          var startY = e.clientY
          var startW = el.offsetWidth
          var startH = el.offsetHeight

          function onMove(e) {
            el.style.width = Math.max(120, startW + e.clientX - startX) + 'px'
            el.style.height = Math.max(44, startH + e.clientY - startY) + 'px'
            if (onResize) onResize(el)
          }

          function onUp() {
            localStorage.setItem(wKey, el.offsetWidth.toString())
            localStorage.setItem(hKey, el.offsetHeight.toString())
            document.removeEventListener('mousemove', onMove)
            document.removeEventListener('mouseup', onUp)
          }

          document.addEventListener('mousemove', onMove)
          document.addEventListener('mouseup', onUp)
        })
      }

      var panelHeader = panel.querySelector('.cp-header')
      makeDraggable(panel, panelHeader, 'cp_pos_panel')
      makeDraggable(hud, hud, 'cp_pos_damage')
      makeResizable(hud, hud.querySelector('.cp-hud-grip'), 'cp_w_damage', 'cp_h_damage', updateHudScale)
      updateHudScale(hud, damageH)

      if (survivalHud) {
        makeDraggable(survivalHud, survivalHud, 'cp_pos_survival')
        makeResizable(survivalHud, survivalHud.querySelector('.cp-hud-grip'), 'cp_w_survival', 'cp_h_survival', updateHudScale)
        updateHudScale(survivalHud, survivalH)
      }

      scope.toggleCollapse = function() {
        scope.collapsed = !scope.collapsed
        localStorage.setItem('cp_collapsed', JSON.stringify(scope.collapsed))
      }

      scope.toggleHud = function() {
        scope.hudOn = !scope.hudOn
        bngApi.engineLua('extensions.creatorpack.setHudVisible(' + (scope.hudOn ? 'true' : 'false') + ')')
      }

      scope.toggleSurvival = function() {
        scope.survivalOn = !scope.survivalOn
        bngApi.engineLua('extensions.creatorpack.setSurvivalVisible(' + (scope.survivalOn ? 'true' : 'false') + ')')
      }

      scope.onSensitivityChange = function() {
        localStorage.setItem('cp_sensitivity', JSON.stringify(scope.sensitivity))
        bngApi.engineLua('extensions.creatorpack.setSensitivity(' + scope.sensitivity + ')')
      }

      bngApi.engineLua('extensions.creatorpack.setSensitivity(' + scope.sensitivity + ')')

      var bumpTimer = null
      var bumpDelay = null

      var unsubDamage = $rootScope.$on('creatorpack.damage', function(e, data) {
        if (data.cost !== scope.cost) {
          if (bumpDelay) clearTimeout(bumpDelay)
          if (bumpTimer) clearTimeout(bumpTimer)
          scope.bumping = false
          scope.cost = data.cost
          bumpDelay = setTimeout(function() {
            scope.bumping = true
            scope.$applyAsync()
            bumpTimer = setTimeout(function() {
              scope.bumping = false
              scope.$applyAsync()
            }, 300)
          }, 10)
        }
      })

      var unsubVis = $rootScope.$on('creatorpack.visibility', function(e, data) {
        scope.hudOn = data.visible
        scope.$applyAsync()
      })

      var unsubSurvival = $rootScope.$on('creatorpack.survival', function(e, data) {
        var s = data.survival
        if (s !== scope.survival) {
          scope.survival = s
          scope.survivalColor = s >= 70 ? '#ffffff' : s >= 40 ? '#f5a623' : '#e8453c'
          if (survivalBumpDelay) clearTimeout(survivalBumpDelay)
          if (survivalBumpTimer) clearTimeout(survivalBumpTimer)
          scope.survivalBumping = false
          survivalBumpDelay = setTimeout(function() {
            scope.survivalBumping = true
            scope.$applyAsync()
            survivalBumpTimer = setTimeout(function() {
              scope.survivalBumping = false
              scope.$applyAsync()
            }, 300)
          }, 10)
        }
      })

      var unsubSurvivalVis = $rootScope.$on('creatorpack.survivalVisibility', function(e, data) {
        scope.survivalOn = data.visible
        scope.$applyAsync()
      })

      scope.$on('$destroy', function() {
        unsubDamage()
        unsubVis()
        if (bumpDelay) clearTimeout(bumpDelay)
        if (bumpTimer) clearTimeout(bumpTimer)
        unsubSurvival()
        unsubSurvivalVis()
        if (survivalBumpDelay) clearTimeout(survivalBumpDelay)
        if (survivalBumpTimer) clearTimeout(survivalBumpTimer)
      })
    }
  }
}])