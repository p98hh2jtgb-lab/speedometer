local M = {}

local hudVisible = false
local survivalVisible = false
local lastVel = nil
local accumulatedImpactPenalty = 0
local timer = 0
local interval = 0.5

local impactCooldown = 0
local resetImmunity = 0
local gThreshold = 10
local cachedMode = 'fallback'
local cachedInventoryId = nil
local cachedMultiplier = nil
local cachedVehId = nil

local function resolveVehicleValue()
  local vehId = be:getPlayerVehicleID(0)
  cachedVehId = vehId
  cachedMode = 'fallback'
  cachedInventoryId = nil
  cachedMultiplier = nil

  if not vehId then return end

  if career_career and career_career.isActive() and career_modules_inventory and career_modules_valueCalculator then
    local invId = career_modules_inventory.getInventoryIdFromVehicleId(vehId)
    if invId then
      cachedMode = 'career'
      cachedInventoryId = invId
      return
    end
  end

  local veh = be:getObject(vehId)
  if veh and veh.JBeam and veh.partConfig then
    local configKey = string.match(veh.partConfig, "vehicles/" .. veh.JBeam .. "/(.-)%.pc$")
    if configKey then
      local configInfo = core_vehicles.getConfig(veh.JBeam, configKey)
      if configInfo and configInfo.Value and configInfo.Value > 0 then
        cachedMode = 'jbeam'
        cachedMultiplier = configInfo.Value
        return
      end
    end
  end
end

local function calcCost()
  local vehId = be:getPlayerVehicleID(0)
  if not vehId then return 0 end

  if vehId ~= cachedVehId then
    resolveVehicleValue()
  end

  local obj = map.objects[vehId]
  if not obj then return 0 end
  local raw = obj.damage or 0

  if cachedMode == 'career' and cachedInventoryId then
    local vehicles = career_modules_inventory.getVehicles()
    local invVehInfo = vehicles and vehicles[cachedInventoryId]
    if invVehInfo then
      local details = career_modules_valueCalculator.getRepairDetails(invVehInfo)
      if details then return math.floor(details.price) end
    end
  end

  if cachedMode == 'jbeam' and cachedMultiplier then
    return math.floor(raw * cachedMultiplier / 300000)
  end

  return math.floor(raw * 0.35)
end

local function calcSurvival()
  if resetImmunity > 0 then return 100 end
  local vehId = be:getPlayerVehicleID(0)
  if not vehId then return 100 end
  local obj = map.objects[vehId]
  if not obj then return 100 end
  local raw = obj.damage or 0
  local damagePressure = math.min((raw / 300000) * 30, 30)
  return math.floor(math.max(0, math.min(100, 100 - accumulatedImpactPenalty - damagePressure)))
end

local function setHudVisible(visible)
  hudVisible = visible
  guihooks.trigger('creatorpack.visibility', { visible = visible })
end

local function setSurvivalVisible(visible)
  survivalVisible = visible
  guihooks.trigger('creatorpack.survivalVisibility', { visible = visible })
end

local function resetSurvival()
  accumulatedImpactPenalty = 0
  lastVel = nil
  impactCooldown = 0
  resetImmunity = 1.5
end

local function onUpdate(dt)
  local vehId = be:getPlayerVehicleID(0)
  if vehId then
    local obj = map.objects[vehId]
    if obj and obj.vel then
      local vel = obj.vel
      if resetImmunity > 0 then
        resetImmunity = resetImmunity - dt
      elseif lastVel and dt > 0 then
        local dx = vel.x - lastVel.x
        local dy = vel.y - lastVel.y
        local dz = vel.z - lastVel.z
        local deltaV = math.sqrt(dx * dx + dy * dy + dz * dz)
        local g = (deltaV / dt) / 9.81
        if impactCooldown > 0 then
          impactCooldown = impactCooldown - dt
        elseif g > gThreshold then
          local penalty = math.min((g - gThreshold) * 1.2, 40)
          accumulatedImpactPenalty = math.min(accumulatedImpactPenalty + penalty, 70)
          impactCooldown = 1.5
        end
      end
      lastVel = { x = vel.x, y = vel.y, z = vel.z }
    end
  end

  timer = timer + dt
  if timer < interval then return end
  timer = 0

  if hudVisible then
    guihooks.trigger('creatorpack.damage', { cost = calcCost() })
  end
  if survivalVisible then
    guihooks.trigger('creatorpack.survival', { survival = calcSurvival() })
  end
end

local function onVehicleSwitched(oldId, newId)
  resolveVehicleValue()
  resetSurvival()
end

local function onVehicleResetted(vehId)
  if vehId == be:getPlayerVehicleID(0) then
    resetSurvival()
  end
end

local function setSensitivity(value)
  gThreshold = 21 - value
end

M.setHudVisible = setHudVisible
M.setSurvivalVisible = setSurvivalVisible
M.setSensitivity = setSensitivity
M.onUpdate = onUpdate
M.onVehicleSwitched = onVehicleSwitched
M.onVehicleResetted = onVehicleResetted

return M
